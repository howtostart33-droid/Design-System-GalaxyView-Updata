/**
 * Galaxy View token mirror for canvas / SVG drawing.
 * CSS source of truth: src/index.css (@theme).
 */
export const gv = {
  space950: "#02040a",
  space900: "#050a16",
  cyan: "#38e1ff",
  cyanSoft: "#7fe9ff",
  blue: "#3d8bff",
  ice: "#dbe9ff",
  steel: "#8aa0bf",
  warm: "#ffd79a",
  red: "#ff5a5a",
} as const;

/** Overlay stroke colours (thin luminous lines — never overpower the sky) */
export const overlay = {
  label: "rgba(127, 233, 255, 0.95)",
  labelMuted: "rgba(219, 233, 255, 0.78)",
  marker: "rgba(56, 225, 255, 0.85)",
  leader: "rgba(56, 225, 255, 0.55)",
  outline: "rgba(190, 225, 255, 0.55)",
  outlineDash: "rgba(140, 190, 240, 0.35)",
  constellation: "rgba(120, 180, 255, 0.34)",
  constellationLabel: "rgba(150, 190, 240, 0.5)",
  grid: "rgba(90, 150, 230, 0.16)",
  ecliptic: "rgba(255, 215, 154, 0.38)",
  horizon: "rgba(56, 225, 255, 0.5)",
  planetLabel: "rgba(255, 225, 180, 0.95)",
} as const;

/** Per-category colour used in chips, search results and markers */
export const KIND_STYLE = {
  galaxy: { label: "Galaxy", color: "#7fb8ff" },
  nebula: { label: "Nebula", color: "#ff8fd0" },
  planetary: { label: "Planetary nebula", color: "#5fe3d8" },
  cluster: { label: "Star cluster", color: "#9fd4ff" },
  star: { label: "Star", color: "#ffffff" },
  planet: { label: "Planet", color: "#ffd79a" },
  moon: { label: "Moon", color: "#e8ecf2" },
  sun: { label: "Sun", color: "#ffcf6b" },
  constellation: { label: "Constellation", color: "#8aa0bf" },
} as const;
