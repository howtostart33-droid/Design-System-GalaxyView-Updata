/**
 * Static catalogue (J2000 coordinates). Sources: Messier/NGC & Hipparcos values as commonly published.
 * Solar-system bodies are NOT here — they are computed live in src/services/catalogService.ts.
 */
export type ObjectKind = "galaxy" | "nebula" | "planetary" | "cluster" | "star" | "planet" | "moon" | "sun" | "constellation";

export interface SkyObject {
  id: string;
  name: string;
  alias?: string;
  kind: ObjectKind;
  type: string;
  ra: number; // deg
  dec: number; // deg
  mag?: number;
  distance?: string;
  /** apparent size in arcminutes (major, minor) and position angle (deg, N→E) */
  size?: { maj: number; min: number; pa?: number };
  constellation?: string;
  desc: string;
  facts?: { label: string; value: string }[];
  /** preferred field of view (deg) when flying to this object */
  fov?: number;
  /** drawing priority for labels (lower = more important) */
  rank?: number;
}

const hms = (h: number, m: number, s = 0) => (h + m / 60 + s / 3600) * 15;
const dms = (d: number, m: number, s = 0) => Math.sign(d || 1) * (Math.abs(d) + m / 60 + s / 3600);
const neg = (d: number, m: number, s = 0) => -(d + m / 60 + s / 3600);

/* ——————————————————— Deep-sky ——————————————————— */
const DSO: SkyObject[] = [
  {
    id: "m31", name: "M31", alias: "Andromeda Galaxy", kind: "galaxy", type: "Spiral galaxy · SA(s)b",
    ra: hms(0, 42, 44.3), dec: dms(41, 16, 9), mag: 3.4, distance: "2.54 million ly",
    size: { maj: 190, min: 60, pa: 35 }, constellation: "Andromeda", fov: 3.3, rank: 0,
    desc: "The nearest large spiral galaxy to the Milky Way and the most distant object routinely visible to the naked eye. It is approaching us at roughly 110 km/s and is expected to merge with the Milky Way in about 4.5 billion years.",
    facts: [
      { label: "Diameter", value: "~152,000 ly" },
      { label: "Stars", value: "~1 trillion" },
      { label: "Radial velocity", value: "−300 km/s" },
    ],
  },
  {
    id: "m32", name: "M32", alias: "Le Gentil", kind: "galaxy", type: "Compact elliptical · cE2",
    ra: hms(0, 42, 41.8), dec: dms(40, 51, 55), mag: 8.1, distance: "2.49 million ly",
    size: { maj: 8.7, min: 6.5, pa: 170 }, constellation: "Andromeda", fov: 0.8, rank: 1,
    desc: "A dense compact elliptical satellite of M31, likely stripped of its outer stars by tidal interaction. It hosts a central black hole of a few million solar masses.",
  },
  {
    id: "m110", name: "M110", alias: "NGC 205", kind: "galaxy", type: "Dwarf elliptical · E5 pec",
    ra: hms(0, 40, 22.1), dec: dms(41, 41, 7), mag: 8.1, distance: "2.69 million ly",
    size: { maj: 21.9, min: 10.9, pa: 170 }, constellation: "Andromeda", fov: 1, rank: 1,
    desc: "A larger, more diffuse satellite of Andromeda. Unusually for a dwarf elliptical, it shows dust patches and a population of young blue stars.",
  },
  {
    id: "ngc206", name: "NGC 206", alias: "Star cloud in M31", kind: "cluster", type: "Stellar association in M31",
    ra: hms(0, 40, 31), dec: dms(40, 44, 21), distance: "2.54 million ly", size: { maj: 4.2, min: 4.2 },
    constellation: "Andromeda", fov: 0.6, rank: 3,
    desc: "The richest star cloud in the Andromeda Galaxy, containing hundreds of hot, young O- and B-type stars in M31's southwestern spiral arm.",
  },
  {
    id: "g1", name: "G1", alias: "Mayall II", kind: "cluster", type: "Globular cluster (M31 halo)",
    ra: hms(0, 32, 46.5), dec: dms(39, 34, 40), mag: 13.8, distance: "2.54 million ly",
    constellation: "Andromeda", fov: 0.4, rank: 4,
    desc: "One of the most massive globular clusters in the Local Group, orbiting in the halo of M31. It may be the remnant core of a dwarf galaxy.",
  },
  {
    id: "ngc185", name: "NGC 185", kind: "galaxy", type: "Dwarf spheroidal galaxy",
    ra: hms(0, 38, 58), dec: dms(48, 20, 15), mag: 9.2, distance: "~2 million ly",
    size: { maj: 11.7, min: 10, pa: 35 }, constellation: "Cassiopeia", fov: 1, rank: 4,
    desc: "A dwarf satellite galaxy of M31, visible in small telescopes as a faint oval glow.",
  },
  {
    id: "ngc147", name: "NGC 147", kind: "galaxy", type: "Dwarf spheroidal galaxy",
    ra: hms(0, 33, 12), dec: dms(48, 30, 32), mag: 9.5, distance: "~2.5 million ly",
    size: { maj: 13.2, min: 7.8, pa: 25 }, constellation: "Cassiopeia", fov: 1, rank: 4,
    desc: "A faint dwarf satellite of M31 and a gravitational partner of NGC 185.",
  },
  {
    id: "m33", name: "M33", alias: "Triangulum Galaxy", kind: "galaxy", type: "Spiral galaxy · SA(s)cd",
    ra: hms(1, 33, 50.9), dec: dms(30, 39, 37), mag: 5.7, distance: "2.73 million ly",
    size: { maj: 70.8, min: 41.7, pa: 23 }, constellation: "Triangulum", fov: 2, rank: 1,
    desc: "The third-largest member of the Local Group. Its low surface brightness makes it a classic dark-sky test object.",
  },
  {
    id: "m76", name: "M76", alias: "Little Dumbbell Nebula", kind: "planetary", type: "Planetary nebula",
    ra: hms(1, 42, 19.9), dec: dms(51, 34, 31), mag: 10.1, distance: "~2,500 ly",
    size: { maj: 2.7, min: 1.8, pa: 40 }, constellation: "Perseus", fov: 0.3, rank: 2,
    desc: "One of the faintest Messier objects: a bipolar planetary nebula formed by the ejected outer layers of a dying star.",
  },
  {
    id: "m34", name: "M34", kind: "cluster", type: "Open cluster",
    ra: hms(2, 42, 5), dec: dms(42, 45, 42), mag: 5.5, distance: "~1,500 ly", size: { maj: 35, min: 35 },
    constellation: "Perseus", fov: 1.5, rank: 3,
    desc: "A bright open cluster of about 100 stars, visible to the naked eye under dark skies.",
  },
  {
    id: "ngc869", name: "NGC 869", alias: "Double Cluster (h Persei)", kind: "cluster", type: "Open cluster",
    ra: hms(2, 19, 0), dec: dms(57, 8, 0), mag: 3.7, distance: "~7,500 ly", size: { maj: 30, min: 30 },
    constellation: "Perseus", fov: 2, rank: 2,
    desc: "The western half of the Double Cluster, a pair of young open clusters easily seen with binoculars.",
  },
  {
    id: "ngc884", name: "NGC 884", alias: "Double Cluster (χ Persei)", kind: "cluster", type: "Open cluster",
    ra: hms(2, 22, 24), dec: dms(57, 6, 0), mag: 3.8, distance: "~7,500 ly", size: { maj: 30, min: 30 },
    constellation: "Perseus", fov: 2, rank: 3,
    desc: "The eastern half of the Double Cluster in Perseus.",
  },
  {
    id: "ngc752", name: "NGC 752", kind: "cluster", type: "Open cluster",
    ra: hms(1, 57, 41), dec: dms(37, 47, 6), mag: 5.7, distance: "~1,300 ly", size: { maj: 75, min: 75 },
    constellation: "Andromeda", fov: 2.5, rank: 4,
    desc: "A large, old open cluster south of Almach, best seen in binoculars.",
  },
  {
    id: "ngc891", name: "NGC 891", kind: "galaxy", type: "Edge-on spiral galaxy",
    ra: hms(2, 22, 33), dec: dms(42, 20, 57), mag: 10, distance: "~30 million ly",
    size: { maj: 13.5, min: 2.5, pa: 22 }, constellation: "Andromeda", fov: 0.5, rank: 4,
    desc: "A striking edge-on spiral bisected by a dark dust lane — a favourite target for astrophotographers.",
  },
  {
    id: "ngc7662", name: "NGC 7662", alias: "Blue Snowball", kind: "planetary", type: "Planetary nebula",
    ra: hms(23, 25, 54), dec: dms(42, 32, 6), mag: 8.6, distance: "~5,600 ly", size: { maj: 0.5, min: 0.5 },
    constellation: "Andromeda", fov: 0.2, rank: 4,
    desc: "A bright, compact planetary nebula with a distinctly blue-green tint in small telescopes.",
  },
  {
    id: "m52", name: "M52", kind: "cluster", type: "Open cluster",
    ra: hms(23, 24, 48), dec: dms(61, 35, 36), mag: 7.3, distance: "~5,000 ly", size: { maj: 13, min: 13 },
    constellation: "Cassiopeia", fov: 0.8, rank: 4, desc: "A rich open cluster in Cassiopeia.",
  },
  {
    id: "m103", name: "M103", kind: "cluster", type: "Open cluster",
    ra: hms(1, 33, 23), dec: dms(60, 39, 0), mag: 7.4, distance: "~10,000 ly", size: { maj: 6, min: 6 },
    constellation: "Cassiopeia", fov: 0.5, rank: 4, desc: "A small, fan-shaped open cluster near δ Cassiopeiae.",
  },
  {
    id: "m45", name: "M45", alias: "Pleiades", kind: "cluster", type: "Open cluster",
    ra: hms(3, 47, 24), dec: dms(24, 7, 0), mag: 1.6, distance: "~444 ly", size: { maj: 110, min: 110 },
    constellation: "Taurus", fov: 3, rank: 1,
    desc: "The Seven Sisters — the most famous open cluster in the sky, containing hot blue stars wrapped in faint reflection nebulosity.",
  },
  {
    id: "m42", name: "M42", alias: "Orion Nebula", kind: "nebula", type: "Emission nebula",
    ra: hms(5, 35, 17.3), dec: neg(5, 23, 28), mag: 4, distance: "~1,344 ly", size: { maj: 85, min: 60 },
    constellation: "Orion", fov: 2, rank: 1,
    desc: "The nearest large region of massive star formation, visible to the naked eye as the middle 'star' of Orion's sword.",
  },
  {
    id: "m1", name: "M1", alias: "Crab Nebula", kind: "nebula", type: "Supernova remnant",
    ra: hms(5, 34, 31.9), dec: dms(22, 0, 52), mag: 8.4, distance: "~6,500 ly", size: { maj: 7, min: 5, pa: 130 },
    constellation: "Taurus", fov: 0.3, rank: 2,
    desc: "The expanding remains of a supernova recorded by astronomers in 1054 AD, powered by a central pulsar.",
  },
  {
    id: "m13", name: "M13", alias: "Hercules Cluster", kind: "cluster", type: "Globular cluster",
    ra: hms(16, 41, 41), dec: dms(36, 27, 36), mag: 5.8, distance: "~22,200 ly", size: { maj: 20, min: 20 },
    constellation: "Hercules", fov: 0.8, rank: 2,
    desc: "The finest globular cluster in the northern sky, containing several hundred thousand stars.",
  },
  {
    id: "m57", name: "M57", alias: "Ring Nebula", kind: "planetary", type: "Planetary nebula",
    ra: hms(18, 53, 35.1), dec: dms(33, 1, 45), mag: 8.8, distance: "~2,600 ly", size: { maj: 1.4, min: 1, pa: 60 },
    constellation: "Lyra", fov: 0.2, rank: 2, desc: "A classic smoke-ring planetary nebula between β and γ Lyrae.",
  },
  {
    id: "m27", name: "M27", alias: "Dumbbell Nebula", kind: "planetary", type: "Planetary nebula",
    ra: hms(19, 59, 36.3), dec: dms(22, 43, 16), mag: 7.5, distance: "~1,360 ly", size: { maj: 8, min: 5.6, pa: 30 },
    constellation: "Vulpecula", fov: 0.4, rank: 2, desc: "The first planetary nebula ever discovered and one of the brightest.",
  },
  {
    id: "m8", name: "M8", alias: "Lagoon Nebula", kind: "nebula", type: "Emission nebula",
    ra: hms(18, 3, 37), dec: neg(24, 23, 12), mag: 6, distance: "~4,100 ly", size: { maj: 90, min: 40 },
    constellation: "Sagittarius", fov: 2, rank: 2, desc: "A giant interstellar cloud and stellar nursery in Sagittarius.",
  },
  {
    id: "m20", name: "M20", alias: "Trifid Nebula", kind: "nebula", type: "Emission/reflection nebula",
    ra: hms(18, 2, 23), dec: neg(23, 1, 48), mag: 6.3, distance: "~5,200 ly", size: { maj: 28, min: 28 },
    constellation: "Sagittarius", fov: 1, rank: 3, desc: "A nebula divided into three lobes by dark dust lanes.",
  },
  {
    id: "m16", name: "M16", alias: "Eagle Nebula", kind: "nebula", type: "Emission nebula + cluster",
    ra: hms(18, 18, 48), dec: neg(13, 49, 0), mag: 6, distance: "~7,000 ly", size: { maj: 35, min: 28 },
    constellation: "Serpens", fov: 1, rank: 3, desc: "Home of the 'Pillars of Creation' imaged by Hubble.",
  },
  {
    id: "m51", name: "M51", alias: "Whirlpool Galaxy", kind: "galaxy", type: "Interacting spiral galaxy",
    ra: hms(13, 29, 52.7), dec: dms(47, 11, 43), mag: 8.4, distance: "~31 million ly", size: { maj: 11.2, min: 6.9, pa: 163 },
    constellation: "Canes Venatici", fov: 0.5, rank: 2, desc: "A grand-design spiral interacting with its companion NGC 5195.",
  },
  {
    id: "m81", name: "M81", alias: "Bode's Galaxy", kind: "galaxy", type: "Spiral galaxy",
    ra: hms(9, 55, 33.2), dec: dms(69, 3, 55), mag: 6.9, distance: "~11.8 million ly", size: { maj: 26.9, min: 14.1, pa: 157 },
    constellation: "Ursa Major", fov: 1.2, rank: 2, desc: "A bright spiral galaxy paired with M82 in Ursa Major.",
  },
  {
    id: "m82", name: "M82", alias: "Cigar Galaxy", kind: "galaxy", type: "Starburst galaxy",
    ra: hms(9, 55, 52.2), dec: dms(69, 40, 47), mag: 8.4, distance: "~11.5 million ly", size: { maj: 11.2, min: 4.3, pa: 65 },
    constellation: "Ursa Major", fov: 0.6, rank: 3, desc: "A starburst galaxy with intense star formation triggered by its encounter with M81.",
  },
  {
    id: "m101", name: "M101", alias: "Pinwheel Galaxy", kind: "galaxy", type: "Spiral galaxy",
    ra: hms(14, 3, 12.6), dec: dms(54, 20, 57), mag: 7.9, distance: "~21 million ly", size: { maj: 28.8, min: 26.9 },
    constellation: "Ursa Major", fov: 1, rank: 3, desc: "A large face-on spiral galaxy with prominent, asymmetric arms.",
  },
  {
    id: "m104", name: "M104", alias: "Sombrero Galaxy", kind: "galaxy", type: "Spiral galaxy",
    ra: hms(12, 39, 59.4), dec: neg(11, 37, 23), mag: 8, distance: "~31 million ly", size: { maj: 8.7, min: 3.5, pa: 90 },
    constellation: "Virgo", fov: 0.4, rank: 3, desc: "A nearly edge-on galaxy with a bright bulge and a prominent dust lane.",
  },
  {
    id: "m15", name: "M15", kind: "cluster", type: "Globular cluster",
    ra: hms(21, 29, 58.3), dec: dms(12, 10, 1), mag: 6.2, distance: "~33,600 ly", size: { maj: 18, min: 18 },
    constellation: "Pegasus", fov: 0.7, rank: 3, desc: "One of the densest globular clusters in the Milky Way, northwest of Enif.",
  },
  {
    id: "ngc7000", name: "NGC 7000", alias: "North America Nebula", kind: "nebula", type: "Emission nebula",
    ra: hms(20, 59, 17), dec: dms(44, 31, 44), mag: 4, distance: "~2,200 ly", size: { maj: 120, min: 100 },
    constellation: "Cygnus", fov: 4, rank: 3, desc: "A large emission nebula near Deneb whose shape resembles the North American continent.",
  },
];

/* ——————————————————— Named stars ——————————————————— */
type StarRow = [id: string, name: string, alias: string, ra: number, dec: number, mag: number, dist: string, con: string, spec: string];
const STAR_ROWS: StarRow[] = [
  ["alpheratz", "Alpheratz", "α Andromedae", hms(0, 8, 23.3), dms(29, 5, 26), 2.06, "97 ly", "Andromeda", "B8 IV-V"],
  ["delta-and", "δ And", "Delta Andromedae", hms(0, 39, 19.7), dms(30, 51, 40), 3.27, "101 ly", "Andromeda", "K3 III"],
  ["mirach", "Mirach", "β Andromedae", hms(1, 9, 43.9), dms(35, 37, 14), 2.05, "197 ly", "Andromeda", "M0 III"],
  ["almach", "Almach", "γ Andromedae", hms(2, 3, 54), dms(42, 19, 47), 2.26, "~350 ly", "Andromeda", "K3 IIb"],
  ["mu-and", "μ And", "Mu Andromedae", hms(0, 56, 45.2), dms(38, 29, 58), 3.87, "~120 ly", "Andromeda", "A5 V"],
  ["nu-and", "ν And", "Nu Andromedae", hms(0, 49, 48.8), dms(41, 4, 44), 4.53, "~680 ly", "Andromeda", "B5 V"],
  ["pi-and", "π And", "Pi Andromedae", hms(0, 36, 52.8), dms(33, 43, 10), 4.36, "~600 ly", "Andromeda", "B5 V"],
  ["32-and", "32 And", "32 Andromedae", hms(0, 41, 7.2), dms(39, 27, 31), 5.3, "345 ly", "Andromeda", "G8 III"],
  ["caph", "Caph", "β Cassiopeiae", hms(0, 9, 10.7), dms(59, 8, 59), 2.28, "55 ly", "Cassiopeia", "F2 III"],
  ["schedar", "Schedar", "α Cassiopeiae", hms(0, 40, 30.4), dms(56, 32, 14), 2.24, "228 ly", "Cassiopeia", "K0 IIIa"],
  ["navi", "γ Cas", "Gamma Cassiopeiae", hms(0, 56, 42.5), dms(60, 43, 0), 2.47, "~550 ly", "Cassiopeia", "B0.5 IVe"],
  ["ruchbah", "Ruchbah", "δ Cassiopeiae", hms(1, 25, 49), dms(60, 14, 7), 2.68, "99 ly", "Cassiopeia", "A5 IV"],
  ["segin", "Segin", "ε Cassiopeiae", hms(1, 54, 23.7), dms(63, 40, 12), 3.37, "~410 ly", "Cassiopeia", "B3 III"],
  ["markab", "Markab", "α Pegasi", hms(23, 4, 45.7), dms(15, 12, 19), 2.48, "133 ly", "Pegasus", "B9 III"],
  ["scheat", "Scheat", "β Pegasi", hms(23, 3, 46.5), dms(28, 4, 58), 2.42, "196 ly", "Pegasus", "M2.5 II-III"],
  ["algenib", "Algenib", "γ Pegasi", hms(0, 13, 14.2), dms(15, 11, 1), 2.83, "~390 ly", "Pegasus", "B2 IV"],
  ["mirfak", "Mirfak", "α Persei", hms(3, 24, 19.4), dms(49, 51, 40), 1.79, "~510 ly", "Perseus", "F5 Ib"],
  ["algol", "Algol", "β Persei", hms(3, 8, 10.1), dms(40, 57, 20), 2.12, "90 ly", "Perseus", "B8 V (eclipsing binary)"],
  ["gamma-per", "γ Per", "Gamma Persei", hms(3, 4, 47.8), dms(53, 30, 23), 2.93, "~250 ly", "Perseus", "G8 III"],
  ["delta-per", "δ Per", "Delta Persei", hms(3, 42, 55.5), dms(47, 47, 15), 3.01, "~520 ly", "Perseus", "B5 III"],
  ["epsilon-per", "ε Per", "Epsilon Persei", hms(3, 57, 51.2), dms(40, 0, 37), 2.89, "~640 ly", "Perseus", "B0.5 V"],
  ["alpha-tri", "Mothallah", "α Trianguli", hms(1, 53, 4.9), dms(29, 34, 44), 3.41, "63 ly", "Triangulum", "F6 IV"],
  ["beta-tri", "β Tri", "Beta Trianguli", hms(2, 9, 32.6), dms(34, 59, 14), 3.0, "127 ly", "Triangulum", "A5 IV"],
  ["gamma-tri", "γ Tri", "Gamma Trianguli", hms(2, 17, 18.9), dms(33, 50, 50), 4.01, "~110 ly", "Triangulum", "A1 V"],
  ["hamal", "Hamal", "α Arietis", hms(2, 7, 10.4), dms(23, 27, 45), 2.0, "66 ly", "Aries", "K2 III"],
  ["sheratan", "Sheratan", "β Arietis", hms(1, 54, 38.4), dms(20, 48, 29), 2.64, "59 ly", "Aries", "A5 V"],
  ["polaris", "Polaris", "α Ursae Minoris", hms(2, 31, 49.1), dms(89, 15, 51), 1.98, "~433 ly", "Ursa Minor", "F7 Ib"],
  ["capella", "Capella", "α Aurigae", hms(5, 16, 41.4), dms(45, 59, 53), 0.08, "43 ly", "Auriga", "G3 III + G0 III"],
  ["aldebaran", "Aldebaran", "α Tauri", hms(4, 35, 55.2), dms(16, 30, 33), 0.86, "65 ly", "Taurus", "K5 III"],
  ["betelgeuse", "Betelgeuse", "α Orionis", hms(5, 55, 10.3), dms(7, 24, 25), 0.42, "~550 ly", "Orion", "M1-2 Ia (variable)"],
  ["rigel", "Rigel", "β Orionis", hms(5, 14, 32.3), neg(8, 12, 6), 0.13, "~860 ly", "Orion", "B8 Ia"],
  ["sirius", "Sirius", "α Canis Majoris", hms(6, 45, 8.9), neg(16, 42, 58), -1.46, "8.6 ly", "Canis Major", "A1 V"],
  ["vega", "Vega", "α Lyrae", hms(18, 36, 56.3), dms(38, 47, 1), 0.03, "25 ly", "Lyra", "A0 V"],
  ["deneb", "Deneb", "α Cygni", hms(20, 41, 25.9), dms(45, 16, 49), 1.25, "~2,600 ly", "Cygnus", "A2 Ia"],
  ["altair", "Altair", "α Aquilae", hms(19, 50, 47), dms(8, 52, 6), 0.77, "16.7 ly", "Aquila", "A7 V"],
  ["arcturus", "Arcturus", "α Boötis", hms(14, 15, 39.7), dms(19, 10, 57), -0.05, "36.7 ly", "Boötes", "K1.5 III"],
  ["spica", "Spica", "α Virginis", hms(13, 25, 11.6), neg(11, 9, 41), 0.97, "~250 ly", "Virgo", "B1 V"],
  ["antares", "Antares", "α Scorpii", hms(16, 29, 24.4), neg(26, 25, 55), 1.06, "~550 ly", "Scorpius", "M1.5 Iab"],
];

const STARS: SkyObject[] = STAR_ROWS.map(([id, name, alias, ra, dec, mag, dist, con, spec]) => ({
  id, name, alias, kind: "star", type: `Star · ${spec}`, ra, dec, mag, distance: dist, constellation: con,
  fov: 3, rank: mag < 1.5 ? 1 : mag < 3 ? 2 : 3,
  desc: `${alias === name ? name : `${name} (${alias})`} is a magnitude ${mag} star in ${con}, about ${dist} away. Spectral class ${spec}.`,
}));

/* ——————————————————— Constellations ——————————————————— */
export interface ConstellationDef {
  obj: SkyObject;
  lines: [string, string][];
}
const con = (id: string, name: string, abbr: string, ra: number, dec: number, fov: number, desc: string, lines: [string, string][]): ConstellationDef => ({
  obj: { id, name, alias: abbr, kind: "constellation", type: "Constellation", ra, dec, fov, rank: 5, desc },
  lines,
});

export const CONSTELLATIONS: ConstellationDef[] = [
  con("con-and", "Andromeda", "And", hms(0, 48), 37, 35, "The chained princess of Greek myth, home of the Andromeda Galaxy (M31).", [
    ["alpheratz", "delta-and"], ["delta-and", "mirach"], ["mirach", "almach"], ["mirach", "mu-and"], ["mu-and", "nu-and"], ["delta-and", "pi-and"],
  ]),
  con("con-cas", "Cassiopeia", "Cas", hms(1, 0), 60, 30, "The queen's distinctive 'W' of bright stars, circumpolar from mid-northern latitudes.", [
    ["caph", "schedar"], ["schedar", "navi"], ["navi", "ruchbah"], ["ruchbah", "segin"],
  ]),
  con("con-peg", "Pegasus", "Peg", hms(22, 42), 20, 40, "The winged horse; its Great Square shares a corner star (Alpheratz) with Andromeda.", [
    ["markab", "scheat"], ["scheat", "alpheratz"], ["alpheratz", "algenib"], ["algenib", "markab"],
  ]),
  con("con-per", "Perseus", "Per", hms(3, 18), 45, 35, "The hero Perseus, containing the Double Cluster and the eclipsing binary Algol.", [
    ["gamma-per", "mirfak"], ["mirfak", "delta-per"], ["delta-per", "epsilon-per"], ["mirfak", "algol"],
  ]),
  con("con-tri", "Triangulum", "Tri", hms(2, 0), 32, 20, "A small triangle of stars that hosts the Triangulum Galaxy (M33).", [
    ["alpha-tri", "beta-tri"], ["beta-tri", "gamma-tri"], ["gamma-tri", "alpha-tri"],
  ]),
  con("con-ari", "Aries", "Ari", hms(2, 38), 20, 25, "The ram, a zodiac constellation southeast of Triangulum.", [["hamal", "sheratan"]]),
  con("con-ori", "Orion", "Ori", hms(5, 35), 5, 35, "The hunter — one of the most recognisable constellations, home of M42.", [["betelgeuse", "rigel"]]),
];

export const STATIC_OBJECTS: SkyObject[] = [...DSO, ...STARS, ...CONSTELLATIONS.map((c) => c.obj)];
export const STATIC_BY_ID = new Map(STATIC_OBJECTS.map((o) => [o.id, o]));

export const TONIGHT_POOL = ["m31", "m32", "m110", "m33", "m45", "m42", "m13", "m57", "m27", "m51", "m81", "m76", "ngc869", "ngc7000", "m15", "m1", "m8", "m104", "m101"];
