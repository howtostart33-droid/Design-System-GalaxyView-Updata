import { CONSTELLATIONS, STATIC_BY_ID, type SkyObject } from "@/data/catalog";
import { overlay } from "@/design/tokens";
import { D2R, R2D, eclipticToEquatorial, fromAltAz, moonPosition, norm360, planetPosition, type Observer } from "@/lib/astro";
import { makeProjector, mulberry32, paToScreen, type Projector, type View } from "@/lib/sky";
import { PLANET_COLORS } from "@/services/catalogService";

export interface SkyLayers {
  labels: boolean;
  constellations: boolean;
  grid: boolean;
  horizon: boolean;
  deepSky: boolean;
  planets: boolean;
  stars: boolean;
  milkyWay: boolean;
  outlines: boolean;
  brightness: number;
  autoRotate: boolean;
}

export const DEFAULT_LAYERS: SkyLayers = {
  labels: true,
  constellations: true,
  grid: false,
  horizon: true,
  deepSky: true,
  planets: true,
  stars: true,
  milkyWay: true,
  outlines: true,
  brightness: 1,
  autoRotate: false,
};

export const limitMag = (fov: number) => 6.2 + 1.7 * Math.log2(Math.max(1, 60 / fov));

/* ——— Galactic helpers ——— */
const AG = 192.85948 * D2R;
const DG = 27.12825 * D2R;
const LNCP = 122.93192 * D2R;
function galToEq(l: number, b: number): [number, number] {
  const lr = l * D2R;
  const br = b * D2R;
  const sd = Math.sin(br) * Math.sin(DG) + Math.cos(br) * Math.cos(DG) * Math.cos(LNCP - lr);
  const ra = AG + Math.atan2(Math.cos(br) * Math.sin(LNCP - lr), Math.sin(br) * Math.cos(DG) - Math.cos(br) * Math.sin(DG) * Math.cos(LNCP - lr));
  return [norm360(ra * R2D), Math.asin(sd) * R2D];
}
function galLat(ra: number, dec: number) {
  const s = Math.sin(dec * D2R) * Math.sin(DG) + Math.cos(dec * D2R) * Math.cos(DG) * Math.cos(ra * D2R - AG);
  return Math.asin(s) * R2D;
}

const STAR_TINTS = ["#ffffff", "#f4f7ff", "#dfe9ff", "#c8dcff", "#fff4dd", "#ffe6bf", "#ffd09a", "#ffb98a"];
const pickTint = (u: number) => STAR_TINTS[Math.min(STAR_TINTS.length - 1, Math.floor(Math.pow(u, 1.5) * STAR_TINTS.length))];

/* ——— Procedural background field (rendering texture only — not catalogue data) ——— */
interface Field {
  ra: Float32Array;
  dec: Float32Array;
  mag: Float32Array;
  tint: string[];
}
function makeField(n: number, seed: number, magFn: (u: number) => number, raRange?: [number, number, number, number]): Field {
  const rng = mulberry32(seed);
  const ra = new Float32Array(n);
  const dec = new Float32Array(n);
  const mag = new Float32Array(n);
  const tint: string[] = [];
  let i = 0;
  let guard = 0;
  while (i < n && guard++ < n * 20) {
    let r: number;
    let d: number;
    if (raRange) {
      const [r0, r1, d0, d1] = raRange;
      r = r0 + rng() * (r1 - r0);
      const s0 = Math.sin(d0 * D2R);
      const s1 = Math.sin(d1 * D2R);
      d = Math.asin(s0 + rng() * (s1 - s0)) * R2D;
    } else {
      r = rng() * 360;
      d = Math.asin(rng() * 2 - 1) * R2D;
    }
    const b = galLat(r, d);
    const keep = 0.3 + 0.7 * Math.exp(-((b / 14) ** 2));
    if (rng() > keep) continue;
    ra[i] = r;
    dec[i] = d;
    mag[i] = magFn(rng());
    tint.push(pickTint(rng()));
    i++;
  }
  // sort by magnitude so draw loops can break early
  const idx = Array.from({ length: i }, (_, k) => k).sort((a, b) => mag[a] - mag[b]);
  const f: Field = { ra: new Float32Array(i), dec: new Float32Array(i), mag: new Float32Array(i), tint: [] };
  idx.forEach((k, j) => {
    f.ra[j] = ra[k];
    f.dec[j] = dec[k];
    f.mag[j] = mag[k];
    f.tint.push(tint[k]);
  });
  return f;
}

let skyField: Field | null = null;
const tileCache = new Map<string, Field>();
const TILE = 2;
function getTile(i: number, j: number): Field {
  const key = `${i}:${j}`;
  let t = tileCache.get(key);
  if (!t) {
    const d0 = -90 + j * TILE;
    const d1 = Math.min(90, d0 + TILE);
    const cosd = Math.cos(((d0 + d1) / 2) * D2R);
    const raW = TILE / Math.max(cosd, 0.05);
    const cols = Math.max(1, Math.round(360 / raW));
    const colW = 360 / cols;
    const ii = ((i % cols) + cols) % cols;
    const n = Math.round(TILE * TILE * 260);
    t = makeField(n, (j * 7919 + ii * 104729) ^ 0x5bd1e995, (u) => 8.4 + 6.2 * (1 - Math.pow(u, 2.6)), [ii * colW, (ii + 1) * colW, d0, d1]);
    tileCache.set(key, t);
    if (tileCache.size > 600) tileCache.delete(tileCache.keys().next().value!);
  }
  return t;
}

/* ——— Milky Way glow puffs ——— */
interface Puff {
  ra: number;
  dec: number;
  size: number;
  a: number;
  warm: boolean;
}
let puffs: Puff[] | null = null;
function getPuffs() {
  if (puffs) return puffs;
  const rng = mulberry32(8080);
  puffs = [];
  for (let k = 0; k < 950; k++) {
    const l = rng() * 360;
    const gauss = (rng() + rng() + rng() - 1.5) * 2;
    const core = Math.cos(((l > 180 ? l - 360 : l) * D2R) / 2) ** 2;
    const b = gauss * (3 + 5 * rng()) * (1 + core * 0.4);
    const [ra, dec] = galToEq(l, b);
    puffs.push({ ra, dec, size: 3 + rng() * 9, a: 0.018 + 0.03 * rng() * (0.5 + core), warm: core > 0.6 && rng() < 0.6 });
  }
  return puffs;
}

let spriteCool: HTMLCanvasElement | null = null;
let spriteWarm: HTMLCanvasElement | null = null;
let spriteStar: HTMLCanvasElement | null = null;
function sprite(inner: string, outer: string) {
  const c = document.createElement("canvas");
  c.width = c.height = 64;
  const g = c.getContext("2d")!;
  const grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grd.addColorStop(0, inner);
  grd.addColorStop(0.45, outer);
  grd.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = grd;
  g.fillRect(0, 0, 64, 64);
  return c;
}

/* ——— Geometry helpers ——— */
function polyline(ctx: CanvasRenderingContext2D, p: Projector, pts: [number, number][], closed = false) {
  ctx.beginPath();
  let pen = false;
  let prev: [number, number] | null = null;
  const list = closed ? [...pts, pts[0]] : pts;
  for (const [ra, dec] of list) {
    const [x, y, c] = p.project(ra, dec);
    const ok = c > 0.08 && Math.abs(x) < p.w * 6 && Math.abs(y) < p.h * 6;
    if (!ok) {
      pen = false;
      prev = null;
      continue;
    }
    if (pen && prev && Math.hypot(x - prev[0], y - prev[1]) > p.w * 2) pen = false;
    if (pen) ctx.lineTo(x, y);
    else ctx.moveTo(x, y);
    pen = true;
    prev = [x, y];
  }
  ctx.stroke();
}

function gridStep(fov: number) {
  const c = [0.25, 0.5, 1, 2, 5, 10, 15, 30];
  return c.find((s) => s >= fov / 5) ?? 30;
}

export function objectPixelRadius(o: SkyObject, scale: number) {
  if (!o.size) return 0;
  return ((o.size.maj / 60) * scale) / 2;
}

/* ——— Orbit tracks (cached per hour) ——— */
let trackCache: { key: number; tracks: { id: string; pts: [number, number][]; ticks: [number, number][] }[] } | null = null;
export function orbitTracks(t: Date) {
  const key = Math.floor(t.getTime() / 3600000);
  if (trackCache?.key === key) return trackCache.tracks;
  const day = 86400000;
  const tracks = ["mercury", "venus", "mars", "jupiter", "saturn", "uranus", "neptune"].map((id) => {
    const pts: [number, number][] = [];
    const ticks: [number, number][] = [];
    for (let d = -60; d <= 60; d += 2) {
      const pos = planetPosition(id, new Date(t.getTime() + d * day));
      pts.push([pos.ra, pos.dec]);
      if (d % 10 === 0) ticks.push([pos.ra, pos.dec]);
    }
    return { id, pts, ticks };
  });
  const mpts: [number, number][] = [];
  const mticks: [number, number][] = [];
  for (let h = -48; h <= 48; h += 3) {
    const pos = moonPosition(new Date(t.getTime() + h * 3600000));
    mpts.push([pos.ra, pos.dec]);
    if (h % 24 === 0) mticks.push([pos.ra, pos.dec]);
  }
  tracks.push({ id: "moon", pts: mpts, ticks: mticks });
  trackCache = { key, tracks };
  return tracks;
}

const ECLIPTIC: [number, number][] = Array.from({ length: 121 }, (_, i) => {
  const e = eclipticToEquatorial(i * 3, 0);
  return [e.ra, e.dec];
});

/* ——— Deep-sky drawing ——— */
const hash = (s: string) => [...s].reduce((h, ch) => (h * 31 + ch.charCodeAt(0)) | 0, 7);

function drawDSO(ctx: CanvasRenderingContext2D, p: Projector, o: SkyObject, brightness: number) {
  const [x, y, c] = p.project(o.ra, o.dec);
  if (c <= 0.05) return;
  const rMaj = Math.max(2.5, objectPixelRadius(o, p.scale));
  const rMin = o.size ? Math.max(2, ((o.size.min / 60) * p.scale) / 2) : rMaj;
  if (x < -rMaj - 20 || y < -rMaj - 20 || x > p.w + rMaj + 20 || y > p.h + rMaj + 20) return;
  const ang = paToScreen(p, o.ra, o.dec, o.size?.pa ?? 0);
  const rng = mulberry32(hash(o.id));
  ctx.save();
  ctx.translate(x, y);
  ctx.globalCompositeOperation = "screen";
  ctx.globalAlpha = Math.min(1, 0.9 * brightness);
  if (o.kind === "galaxy") {
    ctx.rotate(ang);
    ctx.scale(1, rMin / rMaj);
    const g = ctx.createRadialGradient(0, 0, 0, 0, 0, rMaj);
    g.addColorStop(0, "rgba(255,248,232,0.95)");
    g.addColorStop(0.12, "rgba(230,225,255,0.7)");
    g.addColorStop(0.45, "rgba(130,165,255,0.25)");
    g.addColorStop(1, "rgba(60,90,200,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, 0, rMaj, 0, Math.PI * 2);
    ctx.fill();
  } else if (o.kind === "nebula") {
    for (let k = 0; k < 5; k++) {
      const ox = (rng() - 0.5) * rMaj * 0.9;
      const oy = (rng() - 0.5) * rMin * 0.9;
      const rr = rMaj * (0.45 + rng() * 0.5);
      const pink = rng() < 0.65;
      const g = ctx.createRadialGradient(ox, oy, 0, ox, oy, rr);
      g.addColorStop(0, pink ? "rgba(255,120,170,0.45)" : "rgba(90,220,230,0.35)");
      g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = g;
      ctx.fillRect(ox - rr, oy - rr, rr * 2, rr * 2);
    }
  } else if (o.kind === "planetary") {
    ctx.rotate(ang);
    const rr = Math.max(4, rMaj);
    const g = ctx.createRadialGradient(0, 0, rr * 0.3, 0, 0, rr * 1.4);
    g.addColorStop(0, "rgba(95,227,216,0.1)");
    g.addColorStop(0.55, "rgba(95,227,216,0.55)");
    g.addColorStop(1, "rgba(61,139,255,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.ellipse(0, 0, rr * 1.4, rr * 1.4 * (rMin / rMaj), 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#e8f8ff";
    ctx.beginPath();
    ctx.arc(0, 0, 1.2, 0, Math.PI * 2);
    ctx.fill();
  } else if (o.kind === "cluster" && o.id !== "ngc206") {
    const globular = o.type.includes("Globular");
    const rr = Math.max(3, rMaj);
    const g = ctx.createRadialGradient(0, 0, 0, 0, 0, rr);
    g.addColorStop(0, globular ? "rgba(255,240,215,0.8)" : "rgba(170,205,255,0.18)");
    g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g;
    ctx.fillRect(-rr, -rr, rr * 2, rr * 2);
    const n = globular ? 90 : 40;
    ctx.fillStyle = globular ? "#fff1dc" : "#dbe9ff";
    for (let k = 0; k < n; k++) {
      const a = rng() * Math.PI * 2;
      const rad = (globular ? Math.pow(rng(), 1.8) : Math.sqrt(rng())) * rr;
      const s = globular ? 0.8 : 0.6 + rng() * 1.6;
      ctx.globalAlpha = 0.4 + rng() * 0.6;
      ctx.fillRect(Math.cos(a) * rad, Math.sin(a) * rad, s, s);
    }
  }
  ctx.restore();
}

/* ——— Main render ——— */
export interface RenderInput {
  view: View;
  w: number;
  h: number;
  layers: SkyLayers;
  time: Date;
  observer: Observer;
  objects: SkyObject[];
  galaxyImg: HTMLImageElement | null;
  orbits: boolean;
}

export function renderSky(ctx: CanvasRenderingContext2D, input: RenderInput) {
  const { view, w, h, layers, time, observer, objects, galaxyImg, orbits } = input;
  const p = makeProjector(view, w, h);
  const B = layers.brightness;
  if (!spriteCool) {
    spriteCool = sprite("rgba(170,200,255,1)", "rgba(90,130,230,0.35)");
    spriteWarm = sprite("rgba(255,225,190,1)", "rgba(200,150,120,0.3)");
    spriteStar = sprite("rgba(255,255,255,1)", "rgba(160,210,255,0.18)");
  }

  // deep space background
  const bg = ctx.createRadialGradient(w * 0.5, h * 0.45, 0, w * 0.5, h * 0.5, Math.max(w, h) * 0.75);
  bg.addColorStop(0, "#060d1d");
  bg.addColorStop(0.6, "#030712");
  bg.addColorStop(1, "#010208");
  ctx.globalCompositeOperation = "source-over";
  ctx.globalAlpha = 1;
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);

  // Milky Way
  if (layers.milkyWay) {
    ctx.globalCompositeOperation = "screen";
    const fade = Math.min(1, Math.max(0.35, view.fov / 25));
    for (const pf of getPuffs()) {
      const [x, y, c] = p.project(pf.ra, pf.dec);
      if (c < 0.1) continue;
      const r = pf.size * p.scale;
      if (x < -r || y < -r || x > w + r || y > h + r) continue;
      ctx.globalAlpha = pf.a * fade * B;
      ctx.drawImage(pf.warm ? spriteWarm! : spriteCool!, x - r, y - r, r * 2, r * 2);
    }
  }

  // Coordinate grid
  ctx.globalCompositeOperation = "source-over";
  ctx.lineWidth = 1;
  if (layers.grid) {
    const step = gridStep(view.fov);
    ctx.strokeStyle = overlay.grid;
    ctx.globalAlpha = 1;
    ctx.setLineDash([]);
    const span = Math.min(180, view.fov * 1.2 + step);
    const d0 = Math.max(-90, Math.floor((view.dec - span) / step) * step);
    const d1 = Math.min(90, view.dec + span);
    for (let d = d0; d <= d1; d += step) {
      if (Math.abs(d) >= 90) continue;
      polyline(ctx, p, Array.from({ length: 145 }, (_, i) => [i * 2.5, d] as [number, number]));
    }
    const raStep = Math.abs(view.dec) > 70 ? Math.max(step, 15) : step;
    for (let r = 0; r < 360; r += raStep) {
      polyline(ctx, p, Array.from({ length: 73 }, (_, i) => [r, -90 + i * 2.5] as [number, number]));
    }
  }

  // Ecliptic & orbit tracks
  if (orbits) {
    ctx.strokeStyle = overlay.ecliptic;
    ctx.setLineDash([6, 6]);
    polyline(ctx, p, ECLIPTIC);
    ctx.setLineDash([]);
    for (const tr of orbitTracks(time)) {
      const col = tr.id === "moon" ? "#e8ecf2" : PLANET_COLORS[tr.id] ?? "#fff";
      ctx.strokeStyle = col;
      ctx.globalAlpha = 0.45;
      polyline(ctx, p, tr.pts);
      ctx.fillStyle = col;
      for (const [ra, dec] of tr.ticks) {
        const [x, y, c] = p.project(ra, dec);
        if (c > 0.1) ctx.fillRect(x - 1.5, y - 1.5, 3, 3);
      }
      ctx.globalAlpha = 1;
    }
  }

  // Constellation lines
  if (layers.constellations) {
    ctx.strokeStyle = overlay.constellation;
    ctx.lineWidth = 1;
    for (const cdef of CONSTELLATIONS) {
      for (const [a, b] of cdef.lines) {
        const s1 = STATIC_BY_ID.get(a)!;
        const s2 = STATIC_BY_ID.get(b)!;
        const [x1, y1, c1] = p.project(s1.ra, s1.dec);
        const [x2, y2, c2] = p.project(s2.ra, s2.dec);
        if (c1 < 0.1 || c2 < 0.1) continue;
        // shorten ends so lines don't touch the stars
        const dx = x2 - x1;
        const dy = y2 - y1;
        const len = Math.hypot(dx, dy);
        if (len < 14) continue;
        const k = 7 / len;
        ctx.beginPath();
        ctx.moveTo(x1 + dx * k, y1 + dy * k);
        ctx.lineTo(x2 - dx * k, y2 - dy * k);
        ctx.stroke();
      }
    }
  }

  // Stars
  const lim = limitMag(view.fov);
  if (layers.stars) {
    ctx.globalCompositeOperation = "lighter";
    const drawField = (f: Field, fadeIn = 1) => {
      for (let i = 0; i < f.mag.length; i++) {
        const m = f.mag[i];
        if (m > lim) break;
        const [x, y, c] = p.project(f.ra[i], f.dec[i]);
        if (c < 0.1 || x < -4 || y < -4 || x > w + 4 || y > h + 4) continue;
        const r = Math.min(4.5, 0.35 + (lim - m) * 0.36) * B;
        ctx.globalAlpha = Math.min(1, Math.max(0.12, (lim - m) / 2.4)) * fadeIn;
        ctx.fillStyle = f.tint[i];
        if (r < 1.1) ctx.fillRect(x - r, y - r, r * 2, r * 2);
        else {
          ctx.beginPath();
          ctx.arc(x, y, r, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    };
    if (!skyField) skyField = makeField(16000, 2718, (u) => Math.min(9.5, 4.2 + 5.3 * (1 - Math.pow(u, 3))));
    drawField(skyField);
    if (view.fov < 9) {
      const fadeIn = Math.min(1, (9 - view.fov) / 3);
      const span = view.fov * 0.75 + TILE;
      const j0 = Math.max(0, Math.floor((view.dec - span + 90) / TILE));
      const j1 = Math.min(89, Math.floor((view.dec + span + 90) / TILE));
      for (let j = j0; j <= j1; j++) {
        const d0 = -90 + j * TILE;
        const cosd = Math.cos((d0 + TILE / 2) * D2R);
        const cols = Math.max(1, Math.round(360 / (TILE / Math.max(cosd, 0.05))));
        const colW = 360 / cols;
        const raSpan = Math.abs(view.dec) + span > 88 ? 180 : span / Math.max(Math.cos(Math.min(89, Math.abs(view.dec) + span) * D2R), 0.02);
        const i0 = Math.floor((view.ra - raSpan) / colW);
        const i1 = Math.floor((view.ra + raSpan) / colW);
        for (let i = i0; i <= Math.min(i1, i0 + cols - 1); i++) drawField(getTile(i, j), fadeIn);
      }
    }
  }

  // Galaxies / DSOs
  ctx.globalCompositeOperation = "screen";
  const m31 = STATIC_BY_ID.get("m31")!;
  if (galaxyImg && galaxyImg.complete && galaxyImg.naturalWidth > 0) {
    const [gx, gy, gc] = p.project(m31.ra, m31.dec);
    const gw = 3.45 * p.scale;
    if (gc > 0.1 && gx > -gw && gy > -gw && gx < w + gw && gy < h + gw) {
      const gh = gw * (galaxyImg.naturalHeight / galaxyImg.naturalWidth);
      ctx.save();
      ctx.translate(gx, gy);
      ctx.rotate(paToScreen(p, m31.ra, m31.dec, 35));
      ctx.globalAlpha = Math.min(1, 0.92 * B + 0.08);
      ctx.drawImage(galaxyImg, -gw / 2, -gh / 2, gw, gh);
      ctx.restore();
    }
  }
  if (layers.deepSky) {
    for (const o of objects) {
      if (o.id === "m31") continue;
      if (o.kind === "galaxy" || o.kind === "nebula" || o.kind === "planetary" || o.kind === "cluster") drawDSO(ctx, p, o, B);
    }
  }

  // Bright named stars (real catalogue) with soft halos
  if (layers.stars) {
    ctx.globalCompositeOperation = "lighter";
    for (const o of objects) {
      if (o.kind !== "star" || o.mag === undefined) continue;
      const [x, y, c] = p.project(o.ra, o.dec);
      if (c < 0.1 || x < -30 || y < -30 || x > w + 30 || y > h + 30) continue;
      const m = o.mag;
      const r = Math.min(6, 1.2 + (Math.max(lim, 7) - m) * 0.42) * B;
      const tint = o.type.includes(" M") || o.type.includes(" K") ? "#ffd3a6" : o.type.includes(" B") ? "#cfe0ff" : "#fff7ea";
      ctx.globalAlpha = 0.45;
      ctx.drawImage(spriteStar!, x - r * 4, y - r * 4, r * 8, r * 8);
      ctx.globalAlpha = 1;
      ctx.fillStyle = tint;
      ctx.beginPath();
      ctx.arc(x, y, r * 0.75, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // Solar system
  if (layers.planets) {
    ctx.globalCompositeOperation = "source-over";
    const sun = objects.find((o) => o.id === "sun");
    for (const o of objects) {
      if (o.kind !== "planet" && o.kind !== "moon" && o.kind !== "sun") continue;
      const [x, y, c] = p.project(o.ra, o.dec);
      if (c < 0.1 || x < -80 || y < -80 || x > w + 80 || y > h + 80) continue;
      if (o.kind === "sun") {
        const r = Math.max(10, 0.267 * p.scale);
        ctx.globalCompositeOperation = "lighter";
        ctx.globalAlpha = 0.7;
        ctx.drawImage(spriteWarm!, x - r * 5, y - r * 5, r * 10, r * 10);
        ctx.globalAlpha = 1;
        ctx.fillStyle = "#fff4d6";
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalCompositeOperation = "source-over";
      } else if (o.kind === "moon") {
        const r = Math.max(7, 0.259 * p.scale);
        const illum = moonPosition(time).illum ?? 0.5;
        let ang = 0;
        if (sun) {
          const [sx, sy] = p.project(sun.ra, sun.dec);
          ang = Math.atan2(sy - y, sx - x);
        }
        ctx.globalCompositeOperation = "lighter";
        ctx.globalAlpha = 0.25 + illum * 0.35;
        ctx.drawImage(spriteStar!, x - r * 3.5, y - r * 3.5, r * 7, r * 7);
        ctx.globalCompositeOperation = "source-over";
        ctx.globalAlpha = 1;
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(ang);
        ctx.fillStyle = "#1b2332";
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#e9edf3";
        ctx.beginPath();
        ctx.arc(0, 0, r, -Math.PI / 2, Math.PI / 2);
        const rx = Math.abs(r * (1 - 2 * illum));
        if (illum >= 0.5) ctx.ellipse(0, 0, rx, r, 0, Math.PI / 2, (3 * Math.PI) / 2, false);
        else ctx.ellipse(0, 0, rx, r, 0, Math.PI / 2, -Math.PI / 2, true);
        ctx.fill();
        ctx.restore();
      } else {
        const col = PLANET_COLORS[o.id] ?? "#fff";
        const r = Math.max(2.5, Math.min(7, 3.2 + (1 - (o.mag ?? 5)) * 0.7));
        ctx.globalCompositeOperation = "lighter";
        ctx.globalAlpha = 0.55;
        ctx.drawImage(spriteWarm!, x - r * 4, y - r * 4, r * 8, r * 8);
        ctx.globalCompositeOperation = "source-over";
        ctx.globalAlpha = 1;
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
        if (o.id === "saturn") {
          ctx.strokeStyle = "rgba(243,217,160,0.85)";
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.ellipse(x, y, r * 2.1, r * 0.75, -0.35, 0, Math.PI * 2);
          ctx.stroke();
        }
      }
    }
  }

  // Horizon
  if (layers.horizon) {
    ctx.globalCompositeOperation = "source-over";
    ctx.globalAlpha = 1;
    ctx.strokeStyle = overlay.horizon;
    ctx.lineWidth = 1.5;
    ctx.setLineDash([]);
    const pts = Array.from({ length: 121 }, (_, i) => {
      const e = fromAltAz(0, i * 3, time, observer);
      return [e.ra, e.dec] as [number, number];
    });
    polyline(ctx, p, pts);
    ctx.font = "600 11px Inter, sans-serif";
    ctx.fillStyle = overlay.horizon;
    ctx.textAlign = "center";
    for (const [lbl, az] of [["N", 0], ["E", 90], ["S", 180], ["W", 270]] as const) {
      const e = fromAltAz(0, az, time, observer);
      const [x, y, c] = p.project(e.ra, e.dec);
      if (c > 0.1 && x > 0 && y > 0 && x < w && y < h) ctx.fillText(`${lbl} · horizon`, x, y - 8);
    }
  }
  ctx.globalAlpha = 1;
  ctx.globalCompositeOperation = "source-over";
}
