/**
 * Astronomy math — all positions are computed, not hardcoded.
 * Angles in degrees unless noted. Equatorial coordinates are J2000-ish (no precession/nutation),
 * which is accurate to well under a degree for present-day dates — fine for a visual chart.
 */
export const D2R = Math.PI / 180;
export const R2D = 180 / Math.PI;
const sin = (d: number) => Math.sin(d * D2R);
const cos = (d: number) => Math.cos(d * D2R);
export const norm360 = (d: number) => ((d % 360) + 360) % 360;
export const norm180 = (d: number) => ((((d + 180) % 360) + 360) % 360) - 180;

export const julianDate = (t: Date) => t.getTime() / 86400000 + 2440587.5;

/** Greenwich mean sidereal time (deg) */
export const gmst = (t: Date) => norm360(280.46061837 + 360.98564736629 * (julianDate(t) - 2451545));
export const lst = (t: Date, lonDeg: number) => norm360(gmst(t) + lonDeg);

export interface Observer {
  lat: number;
  lon: number;
  approximate: boolean;
}

export interface AltAz {
  alt: number;
  az: number;
}

export function toAltAz(ra: number, dec: number, t: Date, obs: Observer): AltAz {
  const H = lst(t, obs.lon) - ra;
  const sinAlt = sin(dec) * sin(obs.lat) + cos(dec) * cos(obs.lat) * cos(H);
  const alt = Math.asin(Math.max(-1, Math.min(1, sinAlt))) * R2D;
  const x = -sin(H) * cos(dec);
  const y = sin(dec) * cos(obs.lat) - cos(dec) * sin(obs.lat) * cos(H);
  return { alt, az: norm360(Math.atan2(x, y) * R2D) };
}

export function fromAltAz(alt: number, az: number, t: Date, obs: Observer): { ra: number; dec: number } {
  const sinDec = sin(alt) * sin(obs.lat) + cos(alt) * cos(obs.lat) * cos(az);
  const dec = Math.asin(Math.max(-1, Math.min(1, sinDec))) * R2D;
  const H = Math.atan2(-sin(az) * cos(alt), sin(alt) * cos(obs.lat) - cos(alt) * sin(obs.lat) * cos(az)) * R2D;
  return { ra: norm360(lst(t, obs.lon) - H), dec };
}

/** Great-circle separation (deg) */
export function separation(ra1: number, dec1: number, ra2: number, dec2: number) {
  const c = sin(dec1) * sin(dec2) + cos(dec1) * cos(dec2) * cos(ra1 - ra2);
  return Math.acos(Math.max(-1, Math.min(1, c))) * R2D;
}

const OBLIQUITY = 23.43928;
function eclToEq(x: number, y: number, z: number) {
  const ye = y * cos(OBLIQUITY) - z * sin(OBLIQUITY);
  const ze = y * sin(OBLIQUITY) + z * cos(OBLIQUITY);
  return {
    ra: norm360(Math.atan2(ye, x) * R2D),
    dec: Math.atan2(ze, Math.hypot(x, ye)) * R2D,
    dist: Math.hypot(x, y, z),
  };
}
export const eclipticToEquatorial = (lambda: number, beta: number) =>
  eclToEq(cos(beta) * cos(lambda), cos(beta) * sin(lambda), sin(beta));

/* ——— Planets: JPL "Approximate Positions of the Planets" (Standish), valid 1800–2050 ——— */
type El = [number, number, number, number, number, number];
const ELEMENTS: Record<string, { e0: El; rate: El; H: number }> = {
  mercury: { e0: [0.38709927, 0.20563593, 7.00497902, 252.2503235, 77.45779628, 48.33076593], rate: [0.00000037, 0.00001906, -0.00594749, 149472.67411175, 0.16047689, -0.12534081], H: -0.6 },
  venus: { e0: [0.72333566, 0.00677672, 3.39467605, 181.9790995, 131.60246718, 76.67984255], rate: [0.0000039, -0.00004107, -0.0007889, 58517.81538729, 0.00268329, -0.27769418], H: -4.4 },
  earth: { e0: [1.00000261, 0.01671123, -0.00001531, 100.46457166, 102.93768193, 0], rate: [0.00000562, -0.00004392, -0.01294668, 35999.37244981, 0.32327364, 0], H: 0 },
  mars: { e0: [1.52371034, 0.0933941, 1.84969142, -4.55343205, -23.94362959, 49.55953891], rate: [0.00001847, 0.00007882, -0.00813131, 19140.30268499, 0.44441088, -0.29257343], H: -1.5 },
  jupiter: { e0: [5.202887, 0.04838624, 1.30439695, 34.39644051, 14.72847983, 100.47390909], rate: [-0.00011607, -0.00013253, -0.00183714, 3034.74612775, 0.21252668, 0.20469106], H: -9.4 },
  saturn: { e0: [9.53667594, 0.05386179, 2.48599187, 49.95424423, 92.59887831, 113.66242448], rate: [-0.0012506, -0.00050991, 0.00193609, 1222.49362201, -0.41897216, -0.28867794], H: -8.9 },
  uranus: { e0: [19.18916464, 0.04725744, 0.77263783, 313.23810451, 170.9542763, 74.01692503], rate: [-0.00196176, -0.00004397, -0.00242939, 428.48202785, 0.40805281, 0.04240589], H: -7.2 },
  neptune: { e0: [30.06992276, 0.00859048, 1.77004347, -55.12002969, 44.96476227, 131.78422574], rate: [0.00026291, 0.00005105, 0.00035372, 218.45945325, -0.32241464, -0.00508664], H: -6.9 },
};

function helio(name: string, T: number): [number, number, number] {
  const { e0, rate } = ELEMENTS[name];
  const [a, e, I, L, wbar, node] = e0.map((v, i) => v + rate[i] * T) as El;
  const w = wbar - node;
  const M = norm180(L - wbar);
  let E = M + R2D * e * sin(M);
  for (let i = 0; i < 8; i++) {
    const dM = M - (E - R2D * e * sin(E));
    E += dM / (1 - e * cos(E));
  }
  const xp = a * (cos(E) - e);
  const yp = a * Math.sqrt(1 - e * e) * sin(E);
  const x = (cos(w) * cos(node) - sin(w) * sin(node) * cos(I)) * xp + (-sin(w) * cos(node) - cos(w) * sin(node) * cos(I)) * yp;
  const y = (cos(w) * sin(node) + sin(w) * cos(node) * cos(I)) * xp + (-sin(w) * sin(node) + cos(w) * cos(node) * cos(I)) * yp;
  const z = sin(w) * sin(I) * xp + cos(w) * sin(I) * yp;
  return [x, y, z];
}

export interface BodyPosition {
  ra: number;
  dec: number;
  distAU: number;
  mag: number;
  /** Illuminated fraction (Moon only) */
  illum?: number;
  phaseName?: string;
  waxing?: boolean;
  eclLon?: number;
}

const centuries = (t: Date) => (julianDate(t) - 2451545) / 36525;

export function planetPosition(name: string, t: Date): BodyPosition {
  const T = centuries(t);
  const [ex, ey, ez] = helio("earth", T);
  const [px, py, pz] = helio(name, T);
  const g = eclToEq(px - ex, py - ey, pz - ez);
  const r = Math.hypot(px, py, pz);
  const mag = ELEMENTS[name].H + 5 * Math.log10(r * g.dist);
  return { ra: g.ra, dec: g.dec, distAU: g.dist, mag: +mag.toFixed(1) };
}

export function sunPosition(t: Date): BodyPosition {
  const [ex, ey, ez] = helio("earth", centuries(t));
  const g = eclToEq(-ex, -ey, -ez);
  return { ra: g.ra, dec: g.dec, distAU: g.dist, mag: -26.7, eclLon: norm360(Math.atan2(-ey, -ex) * R2D) };
}

/** Low-precision lunar position (Astronomical Almanac), ~0.3° accuracy */
export function moonPosition(t: Date): BodyPosition {
  const d = julianDate(t) - 2451545;
  const L = norm360(218.316 + 13.176396 * d);
  const M = norm360(134.963 + 13.064993 * d);
  const F = norm360(93.272 + 13.22935 * d);
  const lambda = norm360(L + 6.289 * sin(M));
  const beta = 5.128 * sin(F);
  const distKm = 385001 - 20905 * cos(M);
  const eq = eclipticToEquatorial(lambda, beta);
  const sun = sunPosition(t);
  const elong = norm360(lambda - (sun.eclLon ?? 0));
  const illum = (1 - cos(elong)) / 2;
  const waxing = elong < 180;
  const phaseName =
    illum < 0.03 ? "New Moon" : illum > 0.97 ? "Full Moon" : illum < 0.47 ? (waxing ? "Waxing Crescent" : "Waning Crescent") : illum < 0.53 ? (waxing ? "First Quarter" : "Last Quarter") : waxing ? "Waxing Gibbous" : "Waning Gibbous";
  const mag = -12.7 + 2.5 * (1 - illum) * 3.2;
  return { ra: eq.ra, dec: eq.dec, distAU: distKm / 149597870.7, mag: +mag.toFixed(1), illum, waxing, phaseName, eclLon: lambda };
}

/* ——— Formatting ——— */
const pad = (n: number, w = 2) => String(n).padStart(w, "0");

export function formatRA(raDeg: number) {
  const h = norm360(raDeg) / 15;
  let hh = Math.floor(h);
  let mm = Math.floor((h - hh) * 60);
  let ss = Math.round(((h - hh) * 60 - mm) * 60);
  if (ss === 60) (ss = 0), mm++;
  if (mm === 60) (mm = 0), hh = (hh + 1) % 24;
  return `${pad(hh)}h ${pad(mm)}m ${pad(ss)}s`;
}

export function formatDec(decDeg: number) {
  const s = decDeg < 0 ? "−" : "+";
  const a = Math.abs(decDeg);
  let d = Math.floor(a);
  let m = Math.floor((a - d) * 60);
  let sec = Math.round(((a - d) * 60 - m) * 60);
  if (sec === 60) (sec = 0), m++;
  if (m === 60) (m = 0), d++;
  return `${s}${pad(d)}° ${pad(m)}′ ${pad(sec)}″`;
}

export function formatAngle(deg: number) {
  if (deg >= 1) return `${deg.toFixed(deg >= 10 ? 0 : 1)}°`;
  const m = deg * 60;
  if (m >= 1) return `${m.toFixed(m >= 10 ? 0 : 1)}′`;
  return `${(m * 60).toFixed(0)}″`;
}

const DIRS = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
export const compassPoint = (az: number) => DIRS[Math.round(norm360(az) / 22.5) % 16];

export function formatDistanceAU(au: number) {
  if (au < 0.01) return `${Math.round(au * 149597870.7).toLocaleString()} km`;
  return `${au.toFixed(au < 10 ? 2 : 1)} AU`;
}

/** Guess an approximate observer from the browser time zone (used until the user shares location). */
export function approximateObserver(): Observer {
  const lon = Math.max(-180, Math.min(180, (-new Date().getTimezoneOffset() / 60) * 15));
  return { lat: 40, lon, approximate: true };
}
