import { D2R, R2D, norm360 } from "@/lib/astro";

/** Chart view: gnomonic projection centred on (ra, dec). fov = horizontal field in degrees. */
export interface View {
  ra: number;
  dec: number;
  fov: number;
  rot: number; // screen rotation (deg)
}

/** M31 centre; rot chosen so the galaxy's major axis (PA 35°) sits horizontal like the reference. */
export const DEFAULT_VIEW: View = { ra: 10.6847, dec: 41.269, fov: 3.3, rot: -55 };
export const MIN_FOV = 0.1;
export const MAX_FOV = 110;

export const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
export const easeInOut = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export interface Projector {
  /** pixels per degree at the centre of the field */
  scale: number;
  w: number;
  h: number;
  /** returns [x, y, cosc]; cosc <= 0 means behind the tangent plane */
  project(ra: number, dec: number): [number, number, number];
  unproject(px: number, py: number): [number, number];
  /** screen angle (radians, from +x, y down) of celestial north at a point */
  northAngle(ra: number, dec: number): number;
  inView(ra: number, dec: number, pad?: number): boolean;
}

export function makeProjector(view: View, w: number, h: number): Projector {
  const half = Math.min(view.fov, 170) / 2;
  const f = w / 2 / Math.tan(half * D2R); // px per tangent-plane unit
  const scale = f * D2R;
  const ra0 = view.ra * D2R;
  const dec0 = view.dec * D2R;
  const sd0 = Math.sin(dec0);
  const cd0 = Math.cos(dec0);
  const r = view.rot * D2R;
  const cr = Math.cos(r);
  const sr = Math.sin(r);

  const project = (ra: number, dec: number): [number, number, number] => {
    const a = ra * D2R;
    const d = dec * D2R;
    const cd = Math.cos(d);
    const sdd = Math.sin(d);
    const cda = Math.cos(a - ra0);
    const cosc = sd0 * sdd + cd0 * cd * cda;
    const c = Math.max(cosc, 1e-6);
    const xi = (cd * Math.sin(a - ra0)) / c;
    const eta = (cd0 * sdd - sd0 * cd * cda) / c;
    // east is left, north is up
    const sx = -xi * f;
    const sy = -eta * f;
    return [w / 2 + sx * cr - sy * sr, h / 2 + sx * sr + sy * cr, cosc];
  };

  const unproject = (px: number, py: number): [number, number] => {
    const dx = px - w / 2;
    const dy = py - h / 2;
    const sx = dx * cr + dy * sr;
    const sy = -dx * sr + dy * cr;
    const xi = -sx / f;
    const eta = -sy / f;
    const rho = Math.hypot(xi, eta);
    if (rho < 1e-12) return [view.ra, view.dec];
    const c = Math.atan(rho);
    const sc = Math.sin(c);
    const cc = Math.cos(c);
    const dec = Math.asin(cc * sd0 + (eta * sc * cd0) / rho);
    const ra = ra0 + Math.atan2(xi * sc, rho * cd0 * cc - eta * sd0 * sc);
    return [norm360(ra * R2D), dec * R2D];
  };

  const northAngle = (ra: number, dec: number) => {
    const [x1, y1] = project(ra, dec);
    const [x2, y2] = project(ra, Math.min(89.999, dec + 0.05));
    return Math.atan2(y2 - y1, x2 - x1);
  };

  const inView = (ra: number, dec: number, pad = 60) => {
    const [x, y, c] = project(ra, dec);
    return c > 0.05 && x > -pad && y > -pad && x < w + pad && y < h + pad;
  };

  return { scale, w, h, project, unproject, northAngle, inView };
}

/** Screen angle (radians) of a position angle (deg, measured N→E) at a point. */
export function paToScreen(p: Projector, ra: number, dec: number, paDeg: number) {
  // East is 90° counter-clockwise from north on the sky → on screen with east-left, rotate by −PA
  return p.northAngle(ra, dec) - paDeg * D2R;
}
