import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { CalendarDays, CircleHelp, Clock, Info, Search, Settings, Share2, Sparkles, Telescope, type LucideIcon } from "lucide-react";
import { GalaxyViewport, zoomView } from "@/components/sky/GalaxyViewport";
import { BottomNavigation, TOOLS, type ToolId } from "@/components/sky/BottomNavigation";
import { BrandMark, CoordinateDisplay, FieldIndicator, Toast, ViewControls, ZoomControls } from "@/components/sky/HudControls";
import { PanelShell } from "@/components/panels/PanelShell";
import { ObjectSearch } from "@/components/panels/ObjectSearch";
import { ObjectInfoPanel } from "@/components/panels/ObjectInfoPanel";
import { GalaxySettings, OverlayToggles } from "@/components/panels/GalaxySettings";
import { HelpPanel, SCOPES, ScopePanel, SharePanel, SkyWeekPanel, TimePanel, TonightPanel } from "@/components/panels/Panels";
import { approximateObserver, norm180, R2D, separation, toAltAz, type Observer } from "@/lib/astro";
import { DEFAULT_LAYERS, type SkyLayers } from "@/lib/renderSky";
import { clamp, DEFAULT_VIEW, easeInOut, makeProjector, MAX_FOV, MIN_FOV, type View } from "@/lib/sky";
import { localCatalog } from "@/services/catalogService";
import { cn } from "@/utils/cn";

const PANEL_META: Partial<Record<ToolId, { title: string; kicker: string; icon: LucideIcon }>> = {
  search: { title: "Search", kicker: "Object discovery", icon: Search },
  info: { title: "Object info", kicker: "Selected target", icon: Info },
  settings: { title: "Settings", kicker: "Chart & location", icon: Settings },
  time: { title: "Time", kicker: "Chart clock", icon: Clock },
  scope: { title: "Scope", kicker: "Eyepiece view", icon: Telescope },
  skyweek: { title: "SkyWeek", kicker: "Next 7 nights", icon: Sparkles },
  tonight: { title: "Tonight", kicker: "Above your horizon", icon: CalendarDays },
  share: { title: "Share view", kicker: "Galaxy View link", icon: Share2 },
  help: { title: "Help", kicker: "Controls & data", icon: CircleHelp },
};

function load<T>(key: string, fallback: T): T {
  try {
    const v = localStorage.getItem(key);
    return v ? { ...fallback, ...JSON.parse(v) } : fallback;
  } catch {
    return fallback;
  }
}

function readHash() {
  const p = new URLSearchParams(window.location.hash.slice(1));
  const v = p.get("v")?.split(",").map(Number);
  const s = p.get("s");
  const t = Number(p.get("t"));
  const view: View =
    v && v.length === 4 && v.every(Number.isFinite) ? { ra: v[0], dec: clamp(v[1], -89.99, 89.99), fov: clamp(v[2], MIN_FOV, MAX_FOV), rot: v[3] } : DEFAULT_VIEW;
  return { view, sel: s && localCatalog.getById(s, new Date()) ? s : null, offset: Number.isFinite(t) && t > 0 ? t - Date.now() : 0 };
}

export default function App() {
  const initial = useMemo(readHash, []);
  const [view, setViewState] = useState<View>(initial.view);
  const [selectedId, setSelectedId] = useState<string | null>(initial.sel ?? "m31");
  const [panel, setPanel] = useState<ToolId | null>(null);
  const [toggles, setToggles] = useState({ orbit: false, compass: false, night: false });
  const [layers, setLayersState] = useState<SkyLayers>(() => load("gv.layers", DEFAULT_LAYERS));
  const [observer, setObserverState] = useState<Observer>(() => load("gv.observer", approximateObserver()));
  const [offsetMs, setOffsetMs] = useState(initial.offset);
  const [now, setNow] = useState(() => Date.now());
  const [scopeId, setScopeId] = useState<string | null>(null);
  const [toast, setToast] = useState<{ msg: string; n: number } | null>(null);
  const [size, setSize] = useState({ w: 1200, h: 800 });
  const [fullscreen, setFullscreen] = useState(false);
  const flyRef = useRef<number | null>(null);

  const setView = useCallback((fn: (v: View) => View) => setViewState(fn), []);
  const setLayers = useCallback((l: SkyLayers) => {
    setLayersState(l);
    localStorage.setItem("gv.layers", JSON.stringify(l));
  }, []);
  const setObserver = useCallback((o: Observer) => {
    setObserverState(o);
    localStorage.setItem("gv.observer", JSON.stringify(o));
  }, []);

  // Real-time clock
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 30000);
    return () => clearInterval(id);
  }, []);
  const time = useMemo(() => new Date(now + offsetMs), [now, offsetMs]);
  const objects = useMemo(() => localCatalog.objectsAt(time), [time]);
  const selected = selectedId ? localCatalog.getById(selectedId, time) ?? null : null;

  const showToast = useCallback((msg: string) => setToast((t) => ({ msg, n: (t?.n ?? 0) + 1 })), []);
  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => setToast(null), 2200);
    return () => clearTimeout(id);
  }, [toast]);

  const stopFly = useCallback(() => {
    if (flyRef.current) cancelAnimationFrame(flyRef.current);
    flyRef.current = null;
  }, []);

  const flyTo = useCallback(
    (target: Partial<View>) => {
      stopFly();
      const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      let from: View | null = null;
      const start = performance.now();
      const dur = reduce ? 1 : 1100;
      const step = (t0: number) => {
        const k = easeInOut(Math.min(1, (t0 - start) / dur));
        setViewState((v) => {
          if (!from) from = v;
          const f = from;
          const to = { ...f, ...target };
          return {
            ra: f.ra + norm180(to.ra - f.ra) * k,
            dec: f.dec + (to.dec - f.dec) * k,
            fov: Math.exp(Math.log(f.fov) + (Math.log(to.fov) - Math.log(f.fov)) * k),
            rot: f.rot + norm180(to.rot - f.rot) * k,
          };
        });
        flyRef.current = k < 1 ? requestAnimationFrame(step) : null;
      };
      flyRef.current = requestAnimationFrame(step);
    },
    [stopFly],
  );

  const selectObject = useCallback(
    (id: string | null, fly = false) => {
      setSelectedId(id);
      if (!id) return;
      setPanel((p) => (p === "search" || p === "tonight" || p === null || p === "info" ? "info" : p));
      if (fly) {
        const o = localCatalog.getById(id, time);
        if (o) flyTo({ ra: o.ra, dec: o.dec, fov: o.fov ?? view.fov });
      }
    },
    [flyTo, time, view.fov],
  );

  const centered = !!selected && separation(view.ra, view.dec, selected.ra, selected.dec) < view.fov * 0.03;

  const center = useCallback(() => {
    if (selected) {
      flyTo({ ra: selected.ra, dec: selected.dec });
      showToast(`Centered on ${selected.name}`);
    } else {
      flyTo(DEFAULT_VIEW);
      showToast("View reset");
    }
  }, [selected, flyTo, showToast]);

  const zoomBy = useCallback(
    (factor: number) => {
      stopFly();
      setViewState((v) => zoomView(v, factor, size.w, size.h));
    },
    [stopFly, size],
  );

  // Auto-rotate
  useEffect(() => {
    if (!layers.autoRotate) return;
    let last = performance.now();
    let id = 0;
    const tick = (t: number) => {
      const dt = (t - last) / 1000;
      last = t;
      setViewState((v) => ({ ...v, rot: (v.rot + dt * 4) % 360 }));
      id = requestAnimationFrame(tick);
    };
    id = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(id);
  }, [layers.autoRotate]);

  // Fullscreen
  useEffect(() => {
    const on = () => setFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", on);
    return () => document.removeEventListener("fullscreenchange", on);
  }, []);
  const toggleFullscreen = useCallback(() => {
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    else document.documentElement.requestFullscreen?.().catch(() => showToast("Fullscreen not available"));
  }, [showToast]);

  const onTool = useCallback(
    (id: ToolId) => {
      const tool = TOOLS.find((t) => t.id === id)!;
      if (tool.kind === "panel") setPanel((p) => (p === id ? null : id));
      else if (id === "center") center();
      else {
        setToggles((t) => {
          const k = id as keyof typeof t;
          const next = { ...t, [k]: !t[k] };
          showToast(`${tool.label} ${next[k] ? "on" : "off"}`);
          return next;
        });
      }
    },
    [center, showToast],
  );

  // Keyboard
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement).tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") {
        if (e.key === "Escape") setPanel(null);
        return;
      }
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const pan = (dx: number, dy: number) => {
        stopFly();
        setViewState((v) => {
          const p = makeProjector(v, size.w, size.h);
          const [ra, dec] = p.unproject(size.w / 2 + dx * size.w * 0.08, size.h / 2 + dy * size.w * 0.08);
          return { ...v, ra, dec: clamp(dec, -89.99, 89.99) };
        });
      };
      const k = e.key;
      if (k === "Escape") setPanel(null);
      else if (k === "+" || k === "=") zoomBy(1 / 1.3);
      else if (k === "-" || k === "_") zoomBy(1.3);
      else if (k === "ArrowLeft") pan(-1, 0);
      else if (k === "ArrowRight") pan(1, 0);
      else if (k === "ArrowUp") pan(0, -1);
      else if (k === "ArrowDown") pan(0, 1);
      else if (k === "[") setViewState((v) => ({ ...v, rot: v.rot - 5 }));
      else if (k === "]") setViewState((v) => ({ ...v, rot: v.rot + 5 }));
      else if (k === "r" || k === "R") (flyTo(DEFAULT_VIEW), showToast("View reset"));
      else if (k === "f" || k === "F") toggleFullscreen();
      else if (k === "l" || k === "L") (document.querySelector<HTMLButtonElement>("[data-layers-toggle]")?.click());
      else {
        const tool = TOOLS.find((t) => t.key.toLowerCase() === k.toLowerCase());
        if (!tool) return;
        e.preventDefault();
        onTool(tool.id);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onTool, zoomBy, stopFly, flyTo, showToast, toggleFullscreen, size]);

  const onResize = useCallback((w: number, h: number) => setSize({ w, h }), []);

  const proj = useMemo(() => makeProjector(view, size.w, size.h), [view, size]);
  const northDeg = (proj.northAngle(view.ra, view.dec) + Math.PI / 2) * R2D;
  const centerHz = toAltAz(view.ra, view.dec, time, observer);
  const scope = scopeId ? SCOPES.find((s) => s.id === scopeId) ?? null : null;

  const shareUrl = useMemo(() => {
    const base = `${window.location.origin}${window.location.pathname}`;
    const parts = [`v=${view.ra.toFixed(4)},${view.dec.toFixed(4)},${view.fov.toFixed(3)},${view.rot.toFixed(1)}`];
    if (selectedId) parts.push(`s=${selectedId}`);
    if (offsetMs !== 0) parts.push(`t=${time.getTime()}`);
    return `${base}#${parts.join("&")}`;
  }, [view, selectedId, offsetMs, time]);

  const activeTools = useMemo(
    () => ({ ...(panel ? { [panel]: true } : {}), orbit: toggles.orbit, compass: toggles.compass, night: toggles.night, center: centered }),
    [panel, toggles, centered],
  );

  const meta = panel ? PANEL_META[panel] : undefined;

  return (
    <div className="flex h-dvh flex-col overflow-hidden bg-space-950 text-gv-ice">
      <a href="#gv-chart" className="focus-ring sr-only z-[80] rounded-lg bg-gv-cyan px-4 py-2 font-semibold text-space-950 focus:not-sr-only focus:absolute focus:top-3 focus:left-3">
        Skip to chart
      </a>
      <h1 className="sr-only">Galaxy View — real-time astronomy chart</h1>

      <main id="gv-chart" className="relative flex-1 overflow-hidden">
        <GalaxyViewport
          view={view}
          setView={setView}
          layers={layers}
          time={time}
          observer={observer}
          objects={objects}
          selectedId={selectedId}
          onSelect={(id) => selectObject(id)}
          scope={scope ? { fov: scope.fov, label: scope.label } : null}
          compass={toggles.compass}
          orbits={toggles.orbit}
          onUserMove={stopFly}
          onResize={onResize}
        />

        {/* Edge vignette — keeps HUD legible without covering the galaxy */}
        <div aria-hidden className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_55%,rgba(1,3,8,0.55)_100%)]" />

        {/* Top HUD */}
        <div className="pointer-events-none absolute inset-x-0 top-0 z-30 p-3 sm:p-4">
          <div className="flex items-start justify-between gap-3">
            <div className="pointer-events-auto flex flex-col gap-2">
              <div className="flex min-h-12 items-center lg:hidden">
                <BrandMark />
              </div>
              <CoordinateDisplay ra={view.ra} dec={view.dec} alt={centerHz.alt} az={centerHz.az} approximate={observer.approximate} target={selected} onInfo={() => setPanel("info")} />
            </div>
            <div className="pointer-events-auto hidden pt-3 lg:block">
              <BrandMark />
            </div>
            <div className={cn("pointer-events-auto transition-[margin] duration-300", panel && "md:mr-0")}>
              <FieldIndicator fovX={view.fov} fovY={(view.fov * size.h) / Math.max(1, size.w)} northDeg={northDeg} fullscreen={fullscreen} onFullscreen={toggleFullscreen} onNorthUp={() => flyTo({ rot: view.rot - northDeg })} />
            </div>
          </div>
        </div>

        {/* Toast */}
        {toast && (
          <div key={toast.n} className="pointer-events-none absolute top-40 left-1/2 z-40 -translate-x-1/2 lg:top-20">
            <Toast message={toast.msg} />
          </div>
        )}

        {/* Side controls */}
        <div className={cn("absolute bottom-3 left-3 z-30 sm:bottom-4 sm:left-4", panel && "hidden md:block")}>
          <ViewControls onCenter={center} centered={centered} layersPanel={<OverlayToggles compact layers={layers} setLayers={setLayers} />} />
        </div>
        <div className={cn("absolute right-3 bottom-3 z-30 transition-[right] duration-300 sm:right-4 sm:bottom-4", panel ? "hidden md:block md:right-[412px]" : "")}>
          <ZoomControls onZoom={zoomBy} canIn={view.fov > MIN_FOV + 1e-6} canOut={view.fov < MAX_FOV - 1e-6} />
        </div>

        {/* Panels */}
        {panel && meta && (
          <PanelShell key={panel} title={meta.title} kicker={meta.kicker} icon={meta.icon} onClose={() => setPanel(null)}>
            {panel === "search" && <ObjectSearch time={time} onSelect={(id) => selectObject(id, true)} />}
            {panel === "info" && (
              <ObjectInfoPanel
                obj={selected}
                time={time}
                observer={observer}
                onCenter={center}
                onZoom={() => selected && flyTo({ ra: selected.ra, dec: selected.dec, fov: selected.fov ?? view.fov })}
              />
            )}
            {panel === "settings" && (
              <GalaxySettings layers={layers} setLayers={setLayers} rotation={view.rot} setRotation={(r) => setViewState((v) => ({ ...v, rot: r }))} observer={observer} setObserver={setObserver} />
            )}
            {panel === "time" && <TimePanel time={time} offsetMs={offsetMs} setOffsetMs={(ms) => (setNow(Date.now()), setOffsetMs(ms))} />}
            {panel === "scope" && (
              <ScopePanel
                scopeId={scopeId}
                setScopeId={(id) => {
                  setScopeId(id);
                  const s = SCOPES.find((x) => x.id === id);
                  if (s) flyTo({ fov: clamp(s.fov * 1.35, MIN_FOV, MAX_FOV) });
                }}
              />
            )}
            {panel === "skyweek" && <SkyWeekPanel time={time} observer={observer} />}
            {panel === "tonight" && <TonightPanel time={time} observer={observer} onSelect={(id) => selectObject(id, true)} />}
            {panel === "share" && <SharePanel url={shareUrl} title={selected ? `${selected.name} — Galaxy View` : "Galaxy View"} />}
            {panel === "help" && <HelpPanel />}
          </PanelShell>
        )}
      </main>

      <BottomNavigation active={activeTools} onTool={onTool} />

      {/* Night vision: red filter preserves dark adaptation */}
      <div aria-hidden className={cn("pointer-events-none fixed inset-0 z-[70] bg-[#ff2020] mix-blend-multiply transition-opacity duration-500", toggles.night ? "opacity-100" : "opacity-0")} />
    </div>
  );
}
