import { STATIC_BY_ID, STATIC_OBJECTS, type ObjectKind, type SkyObject } from "@/data/catalog";
import { formatDistanceAU, moonPosition, planetPosition, sunPosition } from "@/lib/astro";

/**
 * Data-provider seam. Swap `localCatalog` for an implementation backed by a real service
 * (e.g. SIMBAD / JPL Horizons proxy) without touching UI components.
 */
export interface CatalogProvider {
  /** All objects renderable at time t (static + computed solar-system bodies). */
  objectsAt(t: Date): SkyObject[];
  getById(id: string, t: Date): SkyObject | undefined;
  search(query: string, t: Date, opts?: { kinds?: ObjectKind[]; limit?: number }): Promise<SkyObject[]>;
}

export const SEARCH_CATEGORIES: { id: string; label: string; kinds: ObjectKind[] | null; messier?: boolean }[] = [
  { id: "all", label: "All", kinds: null },
  { id: "stars", label: "Stars", kinds: ["star"] },
  { id: "galaxies", label: "Galaxies", kinds: ["galaxy"] },
  { id: "nebulae", label: "Nebulae", kinds: ["nebula", "planetary"] },
  { id: "clusters", label: "Clusters", kinds: ["cluster"] },
  { id: "solar", label: "Planets & Moon", kinds: ["planet", "moon", "sun"] },
  { id: "constellations", label: "Constellations", kinds: ["constellation"] },
  { id: "messier", label: "Messier", kinds: null, messier: true },
];

const PLANETS: { id: string; name: string; desc: string; color: string }[] = [
  { id: "mercury", name: "Mercury", color: "#c9bfb2", desc: "The smallest planet and closest to the Sun; always seen low in twilight." },
  { id: "venus", name: "Venus", color: "#fff2cc", desc: "The brightest planet, shrouded in reflective sulphuric-acid clouds." },
  { id: "mars", name: "Mars", color: "#ff9a6b", desc: "The red planet; its brightness varies strongly as Earth's distance changes." },
  { id: "jupiter", name: "Jupiter", color: "#ffe2b8", desc: "The largest planet. Binoculars reveal its four Galilean moons." },
  { id: "saturn", name: "Saturn", color: "#f3d9a0", desc: "The ringed planet; the rings are visible in any small telescope." },
  { id: "uranus", name: "Uranus", color: "#a8f0ff", desc: "An ice giant at the edge of naked-eye visibility." },
  { id: "neptune", name: "Neptune", color: "#8fb6ff", desc: "The outermost planet; requires binoculars or a telescope." },
];
export const PLANET_COLORS: Record<string, string> = Object.fromEntries(PLANETS.map((p) => [p.id, p.color]));

/** Solar-system bodies computed for time t (cached per minute). */
let ssCache: { key: number; list: SkyObject[] } | null = null;
export function solarSystemAt(t: Date): SkyObject[] {
  const key = Math.floor(t.getTime() / 60000);
  if (ssCache && ssCache.key === key) return ssCache.list;
  const list: SkyObject[] = PLANETS.map((p) => {
    const pos = planetPosition(p.id, t);
    return {
      id: p.id, name: p.name, kind: "planet", type: "Planet", ra: pos.ra, dec: pos.dec, mag: pos.mag,
      distance: formatDistanceAU(pos.distAU), desc: p.desc, fov: 2, rank: 0,
      facts: [{ label: "Position", value: "Computed live (JPL elements)" }],
    };
  });
  const moon = moonPosition(t);
  list.push({
    id: "moon", name: "Moon", alias: moon.phaseName, kind: "moon", type: "Natural satellite of Earth",
    ra: moon.ra, dec: moon.dec, mag: moon.mag, distance: formatDistanceAU(moon.distAU), fov: 3, rank: 0,
    desc: "Earth's only natural satellite. Its glare washes out faint galaxies — plan deep-sky sessions around the phase.",
    facts: [
      { label: "Phase", value: moon.phaseName ?? "" },
      { label: "Illuminated", value: `${Math.round((moon.illum ?? 0) * 100)}%` },
    ],
  });
  const sun = sunPosition(t);
  list.push({
    id: "sun", name: "Sun", kind: "sun", type: "G2 V star", ra: sun.ra, dec: sun.dec, mag: -26.7,
    distance: formatDistanceAU(sun.distAU), fov: 6, rank: 0,
    desc: "Our star. Never observe the Sun through optics without a certified solar filter.",
  });
  ssCache = { key, list };
  return list;
}

const normalize = (s: string) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[\s\-_.]+/g, "");

function score(o: SkyObject, q: string) {
  const name = normalize(o.name);
  const alias = normalize(o.alias ?? "");
  if (name === q || alias === q) return 0;
  if (name.startsWith(q)) return 1;
  if (alias.startsWith(q)) return 2;
  if (name.includes(q) || alias.includes(q)) return 3;
  if (normalize(o.type).includes(q) || normalize(o.constellation ?? "").includes(q)) return 4;
  return -1;
}

export const isMessier = (o: SkyObject) => /^M\d+$/.test(o.name);

export const localCatalog: CatalogProvider = {
  objectsAt(t) {
    return [...STATIC_OBJECTS, ...solarSystemAt(t)];
  },
  getById(id, t) {
    return STATIC_BY_ID.get(id) ?? solarSystemAt(t).find((o) => o.id === id);
  },
  async search(query, t, opts = {}) {
    const q = normalize(query);
    const pool = this.objectsAt(t).filter((o) => !opts.kinds || opts.kinds.includes(o.kind));
    const ranked = pool
      .map((o) => ({ o, s: q ? score(o, q) : (o.rank ?? 5) }))
      .filter((r) => r.s >= 0)
      .sort((a, b) => a.s - b.s || (a.o.mag ?? 99) - (b.o.mag ?? 99));
    return ranked.slice(0, opts.limit ?? 60).map((r) => r.o);
  },
};
