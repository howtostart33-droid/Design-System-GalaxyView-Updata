import type { HTMLAttributes } from "react";
import { cn } from "@/utils/cn";

/** Glass card — thin luminous border, subtle inner highlight. */
export function Card({ className, active, ...props }: HTMLAttributes<HTMLDivElement> & { active?: boolean }) {
  return (
    <div
      className={cn(
        "rounded-xl border border-gv-cyan/15 bg-space-800/50 transition-colors duration-200",
        active && "glow-active",
        className,
      )}
      {...props}
    />
  );
}

export function CardHeader({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("flex items-center justify-between gap-3 border-b border-gv-cyan/10 px-4 py-3", className)} {...props} />;
}

export function CardTitle({ className, ...props }: HTMLAttributes<HTMLHeadingElement>) {
  return <h3 className={cn("font-display text-base font-semibold tracking-tight text-white", className)} {...props} />;
}

export function CardLabel({ className, ...props }: HTMLAttributes<HTMLParagraphElement>) {
  return <p className={cn("text-[11px] font-semibold tracking-[0.14em] text-gv-cyan/80 uppercase", className)} {...props} />;
}

export function CardDescription({ className, ...props }: HTMLAttributes<HTMLParagraphElement>) {
  return <p className={cn("text-sm leading-relaxed text-gv-steel", className)} {...props} />;
}

export function CardContent({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("p-4", className)} {...props} />;
}

export function CardFooter({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("flex flex-wrap items-center gap-3 px-4 pb-4", className)} {...props} />;
}

/** Key/value metric used in info panels */
export function Stat({ label, value, className }: { label: string; value: string; className?: string }) {
  return (
    <div className={cn("rounded-lg border border-gv-cyan/10 bg-space-900/60 px-3 py-2.5", className)}>
      <dt className="text-[10px] font-semibold tracking-[0.14em] text-gv-steel uppercase">{label}</dt>
      <dd className="mt-0.5 text-sm font-medium text-white tabular-nums">{value}</dd>
    </div>
  );
}
