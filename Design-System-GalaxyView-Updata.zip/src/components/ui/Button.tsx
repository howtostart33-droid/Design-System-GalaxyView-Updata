import { forwardRef, type ButtonHTMLAttributes } from "react";
import { cn } from "@/utils/cn";

type Variant = "default" | "secondary" | "outline" | "ghost";
type Size = "sm" | "default" | "lg" | "icon";

const base =
  "focus-ring relative inline-flex select-none items-center justify-center gap-2 rounded-lg font-medium tracking-wide cursor-pointer " +
  "transition-[background,border-color,box-shadow,color,transform] duration-200 ease-out active:scale-[0.97] " +
  "disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-45";

const variants: Record<Variant, string> = {
  /** Primary: luminous cyan */
  default:
    "border border-gv-cyan/60 bg-gradient-to-b from-gv-cyan/25 to-gv-blue/15 text-white shadow-[0_0_18px_rgba(56,225,255,0.25)] " +
    "hover:border-gv-cyan hover:shadow-[0_0_26px_rgba(56,225,255,0.45)]",
  /** Glass */
  secondary: "glass text-gv-ice hover:border-gv-cyan/50 hover:text-white",
  outline: "border border-gv-cyan/30 bg-transparent text-gv-ice hover:border-gv-cyan/70 hover:bg-gv-cyan/5",
  ghost: "border border-transparent bg-transparent text-gv-steel hover:bg-white/5 hover:text-white",
};

const sizes: Record<Size, string> = {
  sm: "h-9 px-3.5 text-sm",
  default: "h-11 px-5 text-sm",
  lg: "h-12 px-6 text-base",
  icon: "h-11 w-11 p-0",
};

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "default", size = "default", type = "button", ...props }, ref) => (
    <button ref={ref} type={type} className={cn(base, variants[variant], sizes[size], className)} {...props} />
  ),
);
Button.displayName = "Button";
