import { forwardRef, type InputHTMLAttributes } from "react";
import { cn } from "@/utils/cn";

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(({ className, ...props }, ref) => (
  <input
    ref={ref}
    className={cn(
      "h-11 w-full rounded-lg border border-gv-cyan/20 bg-space-900/70 px-4 text-sm text-white placeholder:text-gv-steel/70",
      "transition-[border-color,box-shadow] duration-200 outline-none",
      "focus:border-gv-cyan/70 focus:shadow-[0_0_0_3px_rgba(56,225,255,0.15),0_0_18px_rgba(56,225,255,0.2)]",
      className,
    )}
    {...props}
  />
));
Input.displayName = "Input";

interface SwitchProps {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
  hint?: string;
  compact?: boolean;
}

/** Accessible toggle (role="switch") */
export function Switch({ checked, onChange, label, hint, compact }: SwitchProps) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={cn(
        "focus-ring group flex w-full cursor-pointer items-center justify-between gap-4 rounded-lg text-left transition-colors duration-150 hover:bg-white/[0.04]",
        compact ? "px-2 py-1.5" : "px-3 py-2.5",
      )}
    >
      <span className="min-w-0">
        <span className={cn("block font-medium text-gv-ice", compact ? "text-[13px]" : "text-sm")}>{label}</span>
        {hint && <span className="block text-xs text-gv-steel">{hint}</span>}
      </span>
      <span
        aria-hidden
        className={cn(
          "relative inline-flex h-5 w-9 shrink-0 items-center rounded-full border transition-all duration-200",
          checked ? "border-gv-cyan/80 bg-gv-cyan/30 shadow-[0_0_12px_rgba(56,225,255,0.45)]" : "border-gv-steel/40 bg-space-900",
        )}
      >
        <span
          className={cn(
            "absolute h-3.5 w-3.5 rounded-full transition-all duration-200",
            checked ? "left-[18px] bg-gv-cyan" : "left-0.5 bg-gv-steel",
          )}
        />
      </span>
    </button>
  );
}
