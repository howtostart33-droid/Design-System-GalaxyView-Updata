import { useMemo, useState } from "react";
import { Check, Copy, Radio, Share2 } from "lucide-react";
import { STATIC_BY_ID, TONIGHT_POOL, type SkyObject } from "@/data/catalog";
import { compassPoint, moonPosition, planetPosition, separation, toAltAz, type Observer } from "@/lib/astro";
import { solarSystemAt } from "@/services/catalogService";
import { cn } from "@/utils/cn";
import { Button } from "@/components/ui/Button";
import { Card, CardContent, CardDescription, CardHeader, CardLabel, CardTitle } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { ObjectRow } from "./ObjectSearch";

/* ——————————————— Time ——————————————— */
export function TimePanel({ time, offsetMs, setOffsetMs }: { time: Date; offsetMs: number; setOffsetMs: (ms: number) => void }) {
  const H = 3600000;
  const live = offsetMs === 0;
  const toLocalInput = (d: Date) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  const steps: [string, number][] = [
    ["−1 d", -24 * H],
    ["−1 h", -H],
    ["+1 h", H],
    ["+1 d", 24 * H],
  ];
  return (
    <div className="space-y-6">
      <div className="text-center">
        <p className="font-display text-5xl font-semibold tracking-tight text-white tabular-nums">{time.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</p>
        <p className="mt-1 text-sm text-gv-steel">{time.toLocaleDateString([], { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</p>
        <p className={cn("mt-3 inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-semibold", live ? "glow-active text-gv-cyan" : "border-gv-warm/40 text-gv-warm")}>
          <Radio className="h-3.5 w-3.5" aria-hidden /> {live ? "Live — real time" : `${offsetMs > 0 ? "+" : "−"}${(Math.abs(offsetMs) / H).toFixed(1)} h from now`}
        </p>
      </div>

      <label className="block space-y-2">
        <span className="flex justify-between text-sm text-gv-ice">
          Scrub ±48 h <span className="text-gv-steel tabular-nums">{(offsetMs / H).toFixed(1)} h</span>
        </span>
        <input type="range" min={-48} max={48} step={0.25} value={Math.max(-48, Math.min(48, offsetMs / H))} onChange={(e) => setOffsetMs(+e.target.value * H)} className="gv-range focus-ring w-full" />
      </label>

      <div className="grid grid-cols-5 gap-2">
        {steps.slice(0, 2).map(([l, d]) => (
          <Button key={l} size="sm" variant="secondary" onClick={() => setOffsetMs(offsetMs + d)}>
            {l}
          </Button>
        ))}
        <Button size="sm" variant={live ? "default" : "outline"} onClick={() => setOffsetMs(0)} aria-pressed={live}>
          Now
        </Button>
        {steps.slice(2).map(([l, d]) => (
          <Button key={l} size="sm" variant="secondary" onClick={() => setOffsetMs(offsetMs + d)}>
            {l}
          </Button>
        ))}
      </div>

      <label className="block space-y-1.5">
        <span className="text-sm text-gv-ice">Jump to date & time</span>
        <Input
          type="datetime-local"
          value={toLocalInput(time)}
          onChange={(e) => {
            const t = new Date(e.target.value).getTime();
            if (Number.isFinite(t)) setOffsetMs(t - Date.now());
          }}
          className="[color-scheme:dark]"
        />
      </label>
      <p className="text-xs leading-relaxed text-gv-steel">Planet and Moon positions, the horizon and all altitude readouts update with the chart time.</p>
    </div>
  );
}

/* ——————————————— Scope ——————————————— */
export const SCOPES = [
  { id: "eye", label: "Naked eye", detail: "~100° wide", fov: 100 },
  { id: "bino", label: "10×50 binoculars", detail: "6.5° true field", fov: 6.5 },
  { id: "refr", label: "80 mm refractor · 20×", detail: "2.5° true field", fov: 2.5 },
  { id: "sct", label: "8″ SCT · 80×", detail: "0.65° true field", fov: 0.65 },
  { id: "dob", label: "16″ Dobsonian · 200×", detail: "0.25° true field", fov: 0.25 },
];

export function ScopePanel({ scopeId, setScopeId }: { scopeId: string | null; setScopeId: (id: string | null) => void }) {
  return (
    <div className="space-y-4">
      <p className="text-sm text-gv-steel">Overlay an eyepiece circle to preview what an instrument will show.</p>
      <div className="space-y-2" role="radiogroup" aria-label="Instrument">
        {SCOPES.map((s) => {
          const on = scopeId === s.id;
          return (
            <button
              key={s.id}
              type="button"
              role="radio"
              aria-checked={on}
              onClick={() => setScopeId(on ? null : s.id)}
              className={cn(
                "focus-ring flex w-full cursor-pointer items-center justify-between rounded-xl border px-4 py-3 text-left transition-colors",
                on ? "glow-active" : "border-gv-cyan/15 bg-space-800/40 hover:border-gv-cyan/40",
              )}
            >
              <span>
                <span className="block text-sm font-medium text-white">{s.label}</span>
                <span className="block text-xs text-gv-steel">{s.detail}</span>
              </span>
              <span aria-hidden className="grid h-9 w-9 place-items-center rounded-full border border-gv-cyan/40">
                <span className="rounded-full bg-gv-cyan/70" style={{ width: Math.max(4, Math.min(26, 26 * Math.sqrt(s.fov / 6.5))), height: Math.max(4, Math.min(26, 26 * Math.sqrt(s.fov / 6.5))) }} />
              </span>
            </button>
          );
        })}
      </div>
      {scopeId && (
        <Button variant="ghost" size="sm" onClick={() => setScopeId(null)}>
          Remove eyepiece overlay
        </Button>
      )}
    </div>
  );
}

/* ——————————————— SkyWeek (computed) ——————————————— */
interface NightInfo {
  date: Date;
  phase: string;
  illum: number;
  moonAlt: number;
  conj: { name: string; sep: number } | null;
  planets: string[];
  m31Alt: number;
}

function nightAt(base: Date, dayOffset: number, obs: Observer): NightInfo {
  const d = new Date(base);
  d.setDate(d.getDate() + dayOffset);
  d.setHours(21, 0, 0, 0);
  const moon = moonPosition(d);
  const moonHz = toAltAz(moon.ra, moon.dec, d, obs);
  const bodies: { name: string; ra: number; dec: number }[] = [
    ...["mercury", "venus", "mars", "jupiter", "saturn"].map((id) => ({ name: id[0].toUpperCase() + id.slice(1), ...planetPosition(id, d) })),
    ...["aldebaran", "antares", "spica", "m45", "betelgeuse"].map((id) => STATIC_BY_ID.get(id)!).map((o) => ({ name: o.alias && o.kind === "cluster" ? o.alias : o.name, ra: o.ra, dec: o.dec })),
  ];
  let conj: NightInfo["conj"] = null;
  for (const b of bodies) {
    const s = separation(moon.ra, moon.dec, b.ra, b.dec);
    if (s < 8 && (!conj || s < conj.sep)) conj = { name: b.name, sep: s };
  }
  const planets = ["mercury", "venus", "mars", "jupiter", "saturn"]
    .filter((id) => {
      const p = planetPosition(id, d);
      return toAltAz(p.ra, p.dec, d, obs).alt > 10;
    })
    .map((id) => id[0].toUpperCase() + id.slice(1));
  const m31 = STATIC_BY_ID.get("m31")!;
  const t22 = new Date(d);
  t22.setHours(22);
  return { date: d, phase: moon.phaseName ?? "", illum: moon.illum ?? 0, moonAlt: moonHz.alt, conj, planets, m31Alt: toAltAz(m31.ra, m31.dec, t22, obs).alt };
}

export function SkyWeekPanel({ time, observer }: { time: Date; observer: Observer }) {
  const dayKey = time.toDateString();
  const nights = useMemo(() => Array.from({ length: 7 }, (_, i) => nightAt(time, i, observer)), [dayKey, observer]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div className="space-y-3">
      <p className="text-xs text-gv-steel">Computed for 21:00 local each night{observer.approximate ? " (approximate location)" : ""}.</p>
      <ol className="space-y-3">
        {nights.map((n, i) => (
          <li key={i}>
            <Card>
              <CardHeader className="py-2.5">
                <CardLabel>{i === 0 ? "Tonight" : n.date.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" })}</CardLabel>
                <MoonIcon illum={n.illum} waxing={n.phase.startsWith("Wax") || n.phase === "First Quarter"} />
              </CardHeader>
              <CardContent className="space-y-1.5 py-3">
                <CardTitle className="text-sm">
                  {n.phase} · {Math.round(n.illum * 100)}% lit
                </CardTitle>
                <CardDescription>
                  Moon {n.moonAlt > 0 ? `up at ${n.moonAlt.toFixed(0)}°` : "below the horizon — dark skies for galaxies"}.
                  {n.conj && ` Passes ${n.conj.sep.toFixed(1)}° from ${n.conj.name}.`}
                </CardDescription>
                <CardDescription>
                  {n.planets.length ? `Planets above 10°: ${n.planets.join(", ")}.` : "No bright planets above 10°."} M31 at 22:00: {n.m31Alt.toFixed(0)}°.
                </CardDescription>
              </CardContent>
            </Card>
          </li>
        ))}
      </ol>
    </div>
  );
}

function MoonIcon({ illum, waxing }: { illum: number; waxing: boolean }) {
  const r = 8;
  const rx = Math.abs(r * (1 - 2 * illum));
  const sweepLit = waxing ? 1 : 0;
  const d = `M9 1 A${r} ${r} 0 0 ${sweepLit} 9 17 A${rx} ${r} 0 0 ${illum > 0.5 ? sweepLit : 1 - sweepLit} 9 1`;
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" aria-hidden>
      <circle cx="9" cy="9" r={r} fill="#1b2332" stroke="rgba(219,233,255,0.3)" />
      <path d={d} fill="#e9edf3" />
    </svg>
  );
}

/* ——————————————— Tonight (computed) ——————————————— */
export function TonightPanel({ time, observer, onSelect }: { time: Date; observer: Observer; onSelect: (id: string) => void }) {
  const list = useMemo(() => {
    const pool: SkyObject[] = [...TONIGHT_POOL.map((id) => STATIC_BY_ID.get(id)!), ...solarSystemAt(time).filter((o) => o.kind !== "sun")];
    return pool
      .map((o) => ({ o, hz: toAltAz(o.ra, o.dec, time, observer) }))
      .filter((r) => r.hz.alt > 10)
      .sort((a, b) => b.hz.alt - a.hz.alt);
  }, [time, observer]);
  const sun = solarSystemAt(time).find((o) => o.id === "sun")!;
  const sunAlt = toAltAz(sun.ra, sun.dec, time, observer).alt;
  return (
    <div className="space-y-4">
      <p className="text-xs text-gv-steel">
        Above 10° at {time.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
        {observer.approximate ? " · approximate location" : ""}.{" "}
        {sunAlt > -6 ? <span className="text-gv-warm">The Sun is {sunAlt > 0 ? "up" : "just below the horizon"} — use Time to preview after dark.</span> : "It's dark — good observing."}
      </p>
      <div className="space-y-1">
        {list.map(({ o, hz }) => (
          <ObjectRow key={o.id} o={o} onSelect={onSelect} trailing={<span>{hz.alt.toFixed(0)}° <span className="text-gv-steel/70">{compassPoint(hz.az)}</span></span>} />
        ))}
        {list.length === 0 && <p className="py-6 text-center text-sm text-gv-steel">No catalogue targets above 10° right now.</p>}
      </div>
    </div>
  );
}

/* ——————————————— Share ——————————————— */
export function SharePanel({ url, title }: { url: string; title: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      /* clipboard blocked — field remains selectable */
    }
  };
  const canShare = typeof navigator !== "undefined" && "share" in navigator;
  return (
    <div className="space-y-5">
      <p className="text-sm text-gv-steel">This link restores the exact position, zoom, rotation, time and selected object.</p>
      <label className="block space-y-1.5">
        <span className="text-sm text-gv-ice">View link</span>
        <Input readOnly value={url} onFocus={(e) => e.currentTarget.select()} className="font-mono text-xs" />
      </label>
      <div className="flex flex-wrap gap-2">
        <Button onClick={copy}>
          {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
          {copied ? "Copied" : "Copy link"}
        </Button>
        {canShare && (
          <Button variant="secondary" onClick={() => navigator.share({ title, url }).catch(() => {})}>
            <Share2 className="h-4 w-4" /> Share…
          </Button>
        )}
      </div>
      <p className="sr-only" aria-live="polite">
        {copied ? "Link copied to clipboard" : ""}
      </p>
    </div>
  );
}

/* ——————————————— Help ——————————————— */
export function HelpPanel() {
  const rows: [string, string][] = [
    ["Drag", "Pan the sky"],
    ["Scroll / pinch", "Zoom at pointer"],
    ["Tap / Enter", "Select object"],
    ["+ / −", "Zoom in / out"],
    ["Arrows", "Pan"],
    ["[ / ]", "Rotate field"],
    ["R", "Reset view"],
    ["F", "Fullscreen"],
    ["L", "Layers"],
    ["/", "Search"],
    ["I · C · T · S", "Info · Center · Time · Scope"],
    ["O · K · N", "Orbit · Compass · Night"],
    ["W · G · X", "SkyWeek · Tonight · Share"],
    ["Esc", "Close panel"],
  ];
  return (
    <div className="space-y-6">
      <dl className="space-y-1.5">
        {rows.map(([k, v]) => (
          <div key={k} className="flex items-center justify-between gap-4 rounded-lg px-2 py-1.5 odd:bg-white/[0.02]">
            <dt>
              <kbd className="rounded-md border border-gv-cyan/25 bg-space-900 px-2 py-0.5 font-sans text-xs text-gv-cyan">{k}</kbd>
            </dt>
            <dd className="text-right text-sm text-gv-ice">{v}</dd>
          </div>
        ))}
      </dl>
      <div className="space-y-2 text-xs leading-relaxed text-gv-steel">
        <p className="font-semibold text-gv-ice">About the data</p>
        <p>Stars, galaxies, nebulae and constellations use published J2000 catalogue coordinates. Planets use JPL approximate Keplerian elements; the Moon uses a low-precision lunar theory (~0.3°).</p>
        <p>The faint background star field and Milky Way glow are procedural rendering textures and are not catalogue data. The M31 image is an illustrative texture scaled to the galaxy's true apparent size.</p>
      </div>
    </div>
  );
}
