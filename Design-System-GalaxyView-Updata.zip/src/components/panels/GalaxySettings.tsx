import { useState } from "react";
import { LocateFixed } from "lucide-react";
import type { Observer } from "@/lib/astro";
import type { SkyLayers } from "@/lib/renderSky";
import { Button } from "@/components/ui/Button";
import { Input, Switch } from "@/components/ui/Input";
import { CardLabel } from "@/components/ui/Card";

type BoolKey = { [K in keyof SkyLayers]: SkyLayers[K] extends boolean ? K : never }[keyof SkyLayers];

export const LAYER_ROWS: { key: BoolKey; label: string; hint: string }[] = [
  { key: "labels", label: "Object labels", hint: "Names with leader lines" },
  { key: "constellations", label: "Constellations", hint: "Stick figures & names" },
  { key: "deepSky", label: "Deep-sky objects", hint: "Galaxies, nebulae, clusters" },
  { key: "outlines", label: "Galaxy outlines", hint: "True apparent-size ellipses" },
  { key: "planets", label: "Planets, Moon & Sun", hint: "Computed for chart time" },
  { key: "stars", label: "Stars", hint: "Named stars & star field" },
  { key: "milkyWay", label: "Milky Way", hint: "Galactic-plane glow" },
  { key: "grid", label: "RA/Dec grid", hint: "Equatorial coordinate lines" },
  { key: "horizon", label: "Horizon", hint: "Local horizon for your location" },
];

export function OverlayToggles({ layers, setLayers, compact }: { layers: SkyLayers; setLayers: (l: SkyLayers) => void; compact?: boolean }) {
  return (
    <div className="space-y-0.5">
      {LAYER_ROWS.map((r) => (
        <Switch key={r.key} compact={compact} label={r.label} hint={compact ? undefined : r.hint} checked={layers[r.key]} onChange={(v) => setLayers({ ...layers, [r.key]: v })} />
      ))}
    </div>
  );
}

interface Props {
  layers: SkyLayers;
  setLayers: (l: SkyLayers) => void;
  rotation: number;
  setRotation: (deg: number) => void;
  observer: Observer;
  setObserver: (o: Observer) => void;
}

export function GalaxySettings({ layers, setLayers, rotation, setRotation, observer, setObserver }: Props) {
  const [geoState, setGeoState] = useState<"idle" | "busy" | "error">("idle");
  const locate = () => {
    if (!("geolocation" in navigator)) return setGeoState("error");
    setGeoState("busy");
    navigator.geolocation.getCurrentPosition(
      (p) => {
        setObserver({ lat: +p.coords.latitude.toFixed(4), lon: +p.coords.longitude.toFixed(4), approximate: false });
        setGeoState("idle");
      },
      () => setGeoState("error"),
      { timeout: 10000 },
    );
  };
  const setCoord = (k: "lat" | "lon", v: string) => {
    const n = parseFloat(v);
    if (!Number.isFinite(n)) return;
    const lim = k === "lat" ? 90 : 180;
    setObserver({ ...observer, [k]: Math.max(-lim, Math.min(lim, n)), approximate: false });
  };

  return (
    <div className="space-y-7">
      <section aria-labelledby="set-layers">
        <CardLabel id="set-layers" className="mb-2">
          Overlays
        </CardLabel>
        <OverlayToggles layers={layers} setLayers={setLayers} />
      </section>

      <section aria-labelledby="set-display" className="space-y-4">
        <CardLabel id="set-display">Display</CardLabel>
        <label className="block space-y-2">
          <span className="flex justify-between text-sm text-gv-ice">
            Brightness <span className="text-gv-steel tabular-nums">{Math.round(layers.brightness * 100)}%</span>
          </span>
          <input type="range" min={0.5} max={1.8} step={0.05} value={layers.brightness} onChange={(e) => setLayers({ ...layers, brightness: +e.target.value })} className="gv-range focus-ring w-full" />
        </label>
        <label className="block space-y-2">
          <span className="flex justify-between text-sm text-gv-ice">
            Field rotation <span className="text-gv-steel tabular-nums">{Math.round(rotation)}°</span>
          </span>
          <input type="range" min={-180} max={180} step={1} value={Math.round(((rotation + 540) % 360) - 180)} onChange={(e) => setRotation(+e.target.value)} className="gv-range focus-ring w-full" />
        </label>
        <Switch label="Auto-rotate field" hint="Slowly rotates the chart" checked={layers.autoRotate} onChange={(v) => setLayers({ ...layers, autoRotate: v })} />
      </section>

      <section aria-labelledby="set-loc" className="space-y-3">
        <CardLabel id="set-loc">Observer location</CardLabel>
        <p className="text-xs text-gv-steel">
          {observer.approximate ? "Currently estimated from your time zone. Set your location for accurate altitude, horizon and Tonight lists." : "Used for altitude/azimuth, horizon and Tonight."}
        </p>
        <div className="grid grid-cols-2 gap-2">
          <label className="space-y-1">
            <span className="text-xs text-gv-steel">Latitude</span>
            <Input type="number" step="0.01" min={-90} max={90} defaultValue={observer.lat} key={`lat-${observer.lat}`} onBlur={(e) => setCoord("lat", e.target.value)} />
          </label>
          <label className="space-y-1">
            <span className="text-xs text-gv-steel">Longitude</span>
            <Input type="number" step="0.01" min={-180} max={180} defaultValue={observer.lon} key={`lon-${observer.lon}`} onBlur={(e) => setCoord("lon", e.target.value)} />
          </label>
        </div>
        <Button variant="secondary" size="sm" onClick={locate} disabled={geoState === "busy"}>
          <LocateFixed className="h-4 w-4" strokeWidth={1.8} />
          {geoState === "busy" ? "Locating…" : "Use my location"}
        </Button>
        {geoState === "error" && <p className="text-xs text-[#ff9a9a]" role="alert">Location unavailable — enter coordinates manually.</p>}
      </section>
    </div>
  );
}
