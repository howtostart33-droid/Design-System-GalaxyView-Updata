import { useEffect, useRef, type ReactNode } from "react";
import { X, type LucideIcon } from "lucide-react";
import { cn } from "@/utils/cn";

interface Props {
  title: string;
  kicker: string;
  icon: LucideIcon;
  onClose: () => void;
  children: ReactNode;
  className?: string;
}

/**
 * Translucent side panel (desktop) / bottom sheet (mobile).
 * Kept narrow so the galaxy stays visible behind it.
 */
export function PanelShell({ title, kicker, icon: Icon, onClose, children, className }: Props) {
  const headRef = useRef<HTMLHeadingElement>(null);
  const rootRef = useRef<HTMLElement>(null);
  // Move focus into the panel for keyboard/screen-reader users, unless a child (e.g. search input) already took it
  useEffect(() => {
    if (!rootRef.current?.contains(document.activeElement)) headRef.current?.focus({ preventScroll: true });
  }, [title]);

  return (
    <aside
      ref={rootRef}
      role="dialog"
      aria-modal="false"
      aria-labelledby="gv-panel-title"
      className={cn(
        "glass-strong pointer-events-auto absolute z-40 flex animate-panel-in flex-col overflow-hidden",
        "inset-x-2 bottom-2 max-h-[58%] rounded-2xl",
        "md:inset-x-auto md:top-24 md:right-4 md:bottom-4 md:max-h-none md:w-[380px]",
        className,
      )}
    >
      <header className="flex items-center justify-between gap-3 border-b border-gv-cyan/10 px-5 py-4">
        <div className="flex min-w-0 items-center gap-3">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-gv-cyan/30 bg-gv-cyan/10 text-gv-cyan">
            <Icon className="h-5 w-5" strokeWidth={1.7} aria-hidden />
          </span>
          <div className="min-w-0">
            <p className="text-[11px] font-semibold tracking-[0.16em] text-gv-cyan/75 uppercase">{kicker}</p>
            <h2 id="gv-panel-title" ref={headRef} tabIndex={-1} className="truncate font-display text-xl font-semibold tracking-tight text-white outline-none">
              {title}
            </h2>
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close panel (Esc)"
          className="focus-ring grid h-10 w-10 shrink-0 cursor-pointer place-items-center rounded-lg text-gv-steel transition-colors hover:bg-white/5 hover:text-white"
        >
          <X className="h-5 w-5" strokeWidth={1.8} />
        </button>
      </header>
      <div className="scrollbar-thin relative flex-1 overflow-y-auto overscroll-contain px-5 py-5">{children}</div>
    </aside>
  );
}
