import { useEffect, useId, useRef, useState, type KeyboardEvent, type ReactNode } from "react";
import { Search } from "lucide-react";
import type { ObjectKind, SkyObject } from "@/data/catalog";
import { KIND_STYLE } from "@/design/tokens";
import { isMessier, localCatalog, SEARCH_CATEGORIES, type CatalogProvider } from "@/services/catalogService";
import { cn } from "@/utils/cn";
import { Input } from "@/components/ui/Input";

/** Tiny category glyph (colour-coded, decorative) */
export function KindGlyph({ kind, className }: { kind: ObjectKind; className?: string }) {
  const c = KIND_STYLE[kind].color;
  const common = { width: 18, height: 18, viewBox: "0 0 18 18", "aria-hidden": true, className } as const;
  switch (kind) {
    case "galaxy":
      return (
        <svg {...common}>
          <ellipse cx="9" cy="9" rx="8" ry="3.2" fill="none" stroke={c} strokeWidth="1.2" transform="rotate(-20 9 9)" />
          <circle cx="9" cy="9" r="2" fill={c} />
        </svg>
      );
    case "nebula":
      return (
        <svg {...common}>
          <circle cx="7" cy="9" r="4.5" fill={c} opacity=".45" />
          <circle cx="11" cy="8" r="4" fill={c} opacity=".6" />
        </svg>
      );
    case "planetary":
      return (
        <svg {...common}>
          <circle cx="9" cy="9" r="5" fill="none" stroke={c} strokeWidth="2" />
          <circle cx="9" cy="9" r="1" fill="#fff" />
        </svg>
      );
    case "cluster":
      return (
        <svg {...common}>
          {[[9, 5], [5, 9], [13, 9], [9, 13], [7, 7], [11, 11], [11, 6], [6, 12]].map(([x, y], i) => (
            <circle key={i} cx={x} cy={y} r="1.2" fill={c} />
          ))}
        </svg>
      );
    case "planet":
      return (
        <svg {...common}>
          <circle cx="9" cy="9" r="4" fill={c} />
          <ellipse cx="9" cy="9" rx="8" ry="2.4" fill="none" stroke={c} strokeWidth="1" transform="rotate(-20 9 9)" />
        </svg>
      );
    case "moon":
      return (
        <svg {...common}>
          <path d="M12 3a6.5 6.5 0 1 0 3 11.5A6 6 0 0 1 12 3z" fill={c} />
        </svg>
      );
    case "sun":
      return (
        <svg {...common}>
          <circle cx="9" cy="9" r="4.5" fill={c} />
          <circle cx="9" cy="9" r="7.5" fill="none" stroke={c} strokeOpacity=".4" />
        </svg>
      );
    case "constellation":
      return (
        <svg {...common}>
          <path d="M2 13 7 6l4 5 5-7" fill="none" stroke={c} strokeWidth="1" />
          {[[2, 13], [7, 6], [11, 11], [16, 4]].map(([x, y], i) => (
            <circle key={i} cx={x} cy={y} r="1.5" fill="#fff" />
          ))}
        </svg>
      );
    default:
      return (
        <svg {...common}>
          <path d="M9 1.5 10.6 7.4 16.5 9l-5.9 1.6L9 16.5 7.4 10.6 1.5 9l5.9-1.6z" fill={c} />
        </svg>
      );
  }
}

export function ObjectRow({ o, onSelect, trailing, active, id }: { o: SkyObject; onSelect: (id: string) => void; trailing?: ReactNode; active?: boolean; id?: string }) {
  return (
    <button
      id={id}
      type="button"
      role={id ? "option" : undefined}
      aria-selected={id ? active : undefined}
      onClick={() => onSelect(o.id)}
      className={cn(
        "focus-ring group flex w-full cursor-pointer items-center gap-3 rounded-lg border px-3 py-2.5 text-left transition-colors duration-150",
        active ? "glow-active" : "border-transparent hover:border-gv-cyan/20 hover:bg-gv-cyan/[0.05]",
      )}
    >
      <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-space-900/80 ring-1 ring-gv-cyan/10">
        <KindGlyph kind={o.kind} />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate text-sm font-medium text-white">
          {o.name}
          {o.alias && <span className="ml-2 font-normal text-gv-steel">{o.alias}</span>}
        </span>
        <span className="block truncate text-xs text-gv-steel">
          {o.type}
          {o.constellation ? ` · ${o.constellation}` : ""}
        </span>
      </span>
      <span className="shrink-0 text-right text-xs text-gv-steel tabular-nums">{trailing ?? (o.mag !== undefined ? `mag ${o.mag}` : "")}</span>
    </button>
  );
}

interface Props {
  time: Date;
  onSelect: (id: string) => void;
  provider?: CatalogProvider;
}

export function ObjectSearch({ time, onSelect, provider = localCatalog }: Props) {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("all");
  const [results, setResults] = useState<SkyObject[]>([]);
  const [active, setActive] = useState(0);
  const [loading, setLoading] = useState(false);
  const reqId = useRef(0);
  const listId = useId();

  useEffect(() => {
    const id = ++reqId.current;
    setLoading(true);
    const c = SEARCH_CATEGORIES.find((x) => x.id === cat)!;
    const tmr = setTimeout(async () => {
      let r = await provider.search(q, time, { kinds: c.kinds ?? undefined, limit: 80 });
      if (c.messier) r = r.filter(isMessier).sort((a, b) => +a.name.slice(1) - +b.name.slice(1));
      if (id !== reqId.current) return;
      setResults(r);
      setActive(0);
      setLoading(false);
    }, 120);
    return () => clearTimeout(tmr);
  }, [q, cat, time, provider]);

  const onKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "ArrowDown") (e.preventDefault(), setActive((a) => Math.min(results.length - 1, a + 1)));
    else if (e.key === "ArrowUp") (e.preventDefault(), setActive((a) => Math.max(0, a - 1)));
    else if (e.key === "Enter" && results[active]) onSelect(results[active].id);
  };

  useEffect(() => {
    document.getElementById(`${listId}-${active}`)?.scrollIntoView({ block: "nearest" });
  }, [active, listId]);

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="pointer-events-none absolute top-1/2 left-3.5 h-4 w-4 -translate-y-1/2 text-gv-steel" aria-hidden />
        <Input
          autoFocus
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={onKey}
          placeholder="M31, Vega, Jupiter, Orion…"
          className="pl-10"
          role="combobox"
          aria-expanded={results.length > 0}
          aria-controls={listId}
          aria-activedescendant={results[active] ? `${listId}-${active}` : undefined}
          aria-autocomplete="list"
          aria-label="Search astronomical objects"
        />
      </div>

      <div className="no-scrollbar -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1" role="group" aria-label="Filter by category">
        {SEARCH_CATEGORIES.map((c) => (
          <button
            key={c.id}
            type="button"
            aria-pressed={cat === c.id}
            onClick={() => setCat(c.id)}
            className={cn(
              "focus-ring shrink-0 cursor-pointer rounded-full border px-3 py-1 text-xs font-medium transition-colors",
              cat === c.id ? "glow-active text-gv-cyan" : "border-gv-cyan/15 text-gv-steel hover:border-gv-cyan/40 hover:text-white",
            )}
          >
            {c.label}
          </button>
        ))}
      </div>

      <p className="text-xs text-gv-steel" aria-live="polite">
        {loading ? "Searching…" : `${results.length} ${results.length === 1 ? "result" : "results"}${q ? "" : " · featured"}`}
      </p>

      <div id={listId} role="listbox" aria-label="Search results" className="space-y-1">
        {results.map((o, i) => (
          <ObjectRow key={o.id} id={`${listId}-${i}`} o={o} active={i === active} onSelect={onSelect} />
        ))}
        {!loading && results.length === 0 && <p className="py-6 text-center text-sm text-gv-steel">No objects match “{q}”.</p>}
      </div>
    </div>
  );
}
