import { Crosshair, MousePointerClick, ZoomIn } from "lucide-react";
import type { SkyObject } from "@/data/catalog";
import { KIND_STYLE } from "@/design/tokens";
import { compassPoint, formatAngle, formatDec, formatRA, toAltAz, type Observer } from "@/lib/astro";
import { Button } from "@/components/ui/Button";
import { Stat } from "@/components/ui/Card";
import { KindGlyph } from "./ObjectSearch";

interface Props {
  obj: SkyObject | null;
  time: Date;
  observer: Observer;
  onCenter: () => void;
  onZoom: () => void;
}

export function ObjectInfoPanel({ obj, time, observer, onCenter, onZoom }: Props) {
  if (!obj)
    return (
      <div className="flex flex-col items-center gap-3 py-10 text-center">
        <MousePointerClick className="h-10 w-10 text-gv-cyan/70" strokeWidth={1.4} aria-hidden />
        <p className="font-display text-lg font-semibold text-white">No object selected</p>
        <p className="max-w-[260px] text-sm text-gv-steel">Tap a label or marker on the chart, or use Search to find a target.</p>
      </div>
    );

  const hz = toAltAz(obj.ra, obj.dec, time, observer);
  const live = obj.kind === "planet" || obj.kind === "moon" || obj.kind === "sun";
  const stats: { label: string; value: string }[] = [
    ...(obj.mag !== undefined ? [{ label: live ? "Magnitude (≈)" : "Magnitude", value: String(obj.mag) }] : []),
    ...(obj.distance ? [{ label: "Distance", value: obj.distance }] : []),
    ...(obj.size ? [{ label: "Apparent size", value: obj.size.maj === obj.size.min ? formatAngle(obj.size.maj / 60) : `${formatAngle(obj.size.maj / 60)} × ${formatAngle(obj.size.min / 60)}` }] : []),
    ...(obj.constellation ? [{ label: "Constellation", value: obj.constellation }] : []),
    { label: "Right ascension", value: formatRA(obj.ra) },
    { label: "Declination", value: formatDec(obj.dec) },
    { label: "Altitude", value: `${hz.alt.toFixed(1)}°` },
    { label: "Azimuth", value: `${hz.az.toFixed(1)}° ${compassPoint(hz.az)}` },
    ...(obj.facts ?? []),
  ];

  return (
    <div className="space-y-5">
      <div>
        <div className="flex items-center gap-2">
          <KindGlyph kind={obj.kind} />
          <span className="text-xs font-semibold tracking-[0.12em] uppercase" style={{ color: KIND_STYLE[obj.kind].color }}>
            {KIND_STYLE[obj.kind].label}
          </span>
          {hz.alt < 0 && <span className="rounded bg-gv-red/15 px-1.5 py-px text-[11px] font-semibold text-[#ff9a9a]">Below horizon</span>}
        </div>
        <p className="mt-2 font-display text-3xl font-semibold tracking-tight text-white">{obj.name}</p>
        {obj.alias && <p className="mt-0.5 text-base text-gv-cyan-soft">{obj.alias}</p>}
        <p className="mt-1 text-sm text-gv-steel">{obj.type}</p>
      </div>

      <p className="text-sm leading-relaxed text-gv-ice/90">{obj.desc}</p>

      <dl className="grid grid-cols-2 gap-2">
        {stats.map((s) => (
          <Stat key={s.label} label={s.label} value={s.value} />
        ))}
      </dl>

      <p className="text-[11px] leading-relaxed text-gv-steel/80">
        {live ? "Position computed live for the chart time from orbital elements. " : "J2000 catalogue coordinates. "}
        Alt/Az for {observer.approximate ? "an approximate location — set yours in Settings" : `${observer.lat.toFixed(2)}°, ${observer.lon.toFixed(2)}°`} at{" "}
        {time.toLocaleString([], { hour: "2-digit", minute: "2-digit", month: "short", day: "numeric" })}.
      </p>

      <div className="flex flex-wrap gap-2">
        <Button onClick={onCenter} size="sm">
          <Crosshair className="h-4 w-4" strokeWidth={1.8} /> Center
        </Button>
        <Button onClick={onZoom} variant="secondary" size="sm">
          <ZoomIn className="h-4 w-4" strokeWidth={1.8} /> Frame object
        </Button>
      </div>
    </div>
  );
}
