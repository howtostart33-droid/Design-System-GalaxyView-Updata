import { useEffect, useRef, useState, type ButtonHTMLAttributes, type ReactNode } from "react";
import { Crosshair, Info, Layers, MapPin, Maximize, Minimize, Minus, Navigation, Navigation2, Plus } from "lucide-react";
import type { SkyObject } from "@/data/catalog";
import { compassPoint, formatDec, formatRA } from "@/lib/astro";
import { cn } from "@/utils/cn";

/* ——— Primitive ——— */
export function GlassIconButton({ label, active, className, children, ...rest }: ButtonHTMLAttributes<HTMLButtonElement> & { label: string; active?: boolean }) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      className={cn(
        "focus-ring grid h-12 w-12 cursor-pointer place-items-center rounded-xl border border-transparent text-gv-ice transition-all duration-200 hover:bg-gv-cyan/10 hover:text-white active:scale-95",
        active && "glow-active text-gv-cyan",
        className,
      )}
      {...rest}
    >
      {children}
    </button>
  );
}

/* ——— Brand ——— */
export function BrandMark({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-center gap-2.5 select-none", className)}>
      <svg width="26" height="26" viewBox="0 0 32 32" aria-hidden className="shrink-0">
        <defs>
          <radialGradient id="gv-core" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#fff" />
            <stop offset="45%" stopColor="#7fe9ff" />
            <stop offset="100%" stopColor="#3d8bff" stopOpacity="0" />
          </radialGradient>
        </defs>
        <ellipse cx="16" cy="16" rx="14" ry="5.5" fill="none" stroke="#38e1ff" strokeOpacity="0.8" strokeWidth="1.3" transform="rotate(-18 16 16)" />
        <ellipse cx="16" cy="16" rx="9" ry="3.4" fill="none" stroke="#7fe9ff" strokeOpacity="0.45" strokeWidth="1" strokeDasharray="2 2.5" transform="rotate(-18 16 16)" />
        <circle cx="16" cy="16" r="5" fill="url(#gv-core)" />
      </svg>
      <span className="font-display text-[15px] font-semibold tracking-[0.34em] text-white uppercase">
        Galaxy <span className="text-gv-cyan text-glow">View</span>
      </span>
    </div>
  );
}

/* ——— Coordinates + target ——— */
interface CoordProps {
  ra: number;
  dec: number;
  alt: number;
  az: number;
  approximate: boolean;
  target: SkyObject | null;
  onInfo: () => void;
}
export function CoordinateDisplay({ ra, dec, alt, az, approximate, target, onInfo }: CoordProps) {
  return (
    <div className="flex flex-col items-start gap-2">
      <div className="glass flex items-center gap-3 rounded-2xl px-4 py-2.5" aria-live="polite" aria-atomic="true">
        <MapPin className="h-5 w-5 shrink-0 text-gv-cyan" strokeWidth={1.8} aria-hidden />
        <div>
          <p className="flex flex-wrap items-baseline gap-x-2 text-[15px] font-medium text-white tabular-nums sm:text-base">
            <span>
              <span className="mr-1.5 text-gv-steel">RA</span>
              {formatRA(ra)}
            </span>
            <span className="text-gv-cyan/40" aria-hidden>
              |
            </span>
            <span>
              <span className="mr-1.5 text-gv-steel">Dec</span>
              {formatDec(dec)}
            </span>
          </p>
          <p className="mt-0.5 text-xs text-gv-steel tabular-nums">
            Alt {alt.toFixed(1)}° · Az {az.toFixed(0)}° {compassPoint(az)}
            {alt < 0 && <span className="ml-2 rounded bg-gv-red/15 px-1.5 py-px font-semibold text-[#ff9a9a]">Below horizon</span>}
            {approximate && <span className="ml-2 text-gv-steel/70">· approx. location</span>}
          </p>
        </div>
      </div>
      {target && (
        <div className="flex animate-fade-in items-center gap-2 pl-2">
          <Navigation className="h-4 w-4 text-gv-cyan" strokeWidth={1.8} aria-hidden />
          <span className="text-[15px] font-medium text-white [text-shadow:0_1px_4px_rgba(0,0,0,0.9)]">{target.name}</span>
          <button
            type="button"
            onClick={onInfo}
            aria-label={`Show information about ${target.name}`}
            className="focus-ring grid h-7 w-7 cursor-pointer place-items-center rounded-full text-gv-steel transition-colors hover:bg-gv-cyan/10 hover:text-gv-cyan"
          >
            <Info className="h-4 w-4" strokeWidth={1.8} />
          </button>
        </div>
      )}
    </div>
  );
}

/* ——— Field indicator ——— */
interface FieldProps {
  fovX: number;
  fovY: number;
  northDeg: number;
  fullscreen: boolean;
  onFullscreen: () => void;
  onNorthUp: () => void;
}
const fmtFov = (d: number) => (d >= 10 ? d.toFixed(0) : d >= 1 ? d.toFixed(1) : d.toFixed(2));
export function FieldIndicator({ fovX, fovY, northDeg, fullscreen, onFullscreen, onNorthUp }: FieldProps) {
  return (
    <div className="glass flex items-center gap-1 rounded-2xl py-1 pr-1 pl-1.5">
      <button
        type="button"
        onClick={onNorthUp}
        aria-label={`North is ${Math.round(northDeg)}° from up. Rotate chart to north-up`}
        title="Rotate north-up"
        className="focus-ring grid h-10 w-10 cursor-pointer place-items-center rounded-xl text-gv-ice transition-colors hover:bg-gv-cyan/10 hover:text-gv-cyan"
      >
        <Navigation2 className="h-5 w-5 transition-transform duration-300" strokeWidth={1.7} style={{ transform: `rotate(${northDeg}deg)` }} />
      </button>
      <p className="px-1 text-[15px] font-medium text-white tabular-nums sm:text-base" aria-label={`Field of view ${fmtFov(fovX)} by ${fmtFov(fovY)} degrees`}>
        {fmtFov(fovX)}° × {fmtFov(fovY)}°
      </p>
      <button
        type="button"
        onClick={onFullscreen}
        aria-label={fullscreen ? "Exit fullscreen" : "Enter fullscreen"}
        aria-pressed={fullscreen}
        title={fullscreen ? "Exit fullscreen (F)" : "Fullscreen (F)"}
        className="focus-ring grid h-10 w-10 cursor-pointer place-items-center rounded-xl text-gv-ice transition-colors hover:bg-gv-cyan/10 hover:text-gv-cyan"
      >
        {fullscreen ? <Minimize className="h-5 w-5" strokeWidth={1.7} /> : <Maximize className="h-5 w-5" strokeWidth={1.7} />}
      </button>
    </div>
  );
}

/* ——— Left stack: locate + layers ——— */
export function ViewControls({ onCenter, centered, layersPanel }: { onCenter: () => void; centered: boolean; layersPanel: ReactNode }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const close = (e: Event) => {
      if (e instanceof KeyboardEvent ? e.key === "Escape" : !ref.current?.contains(e.target as Node)) setOpen(false);
    };
    window.addEventListener("pointerdown", close);
    window.addEventListener("keydown", close);
    return () => {
      window.removeEventListener("pointerdown", close);
      window.removeEventListener("keydown", close);
    };
  }, [open]);
  return (
    <div ref={ref} className="relative">
      <div className="glass flex flex-col items-center gap-1 rounded-2xl p-1.5">
        <GlassIconButton label="Center on target (C)" active={centered} onClick={onCenter}>
          <Crosshair className="h-6 w-6" strokeWidth={1.6} />
        </GlassIconButton>
        <span className="h-px w-8 bg-gv-cyan/15" aria-hidden />
        <GlassIconButton label="Chart layers (L)" active={open} aria-expanded={open} aria-haspopup="dialog" data-layers-toggle onClick={() => setOpen((o) => !o)}>
          <Layers className="h-6 w-6" strokeWidth={1.6} />
        </GlassIconButton>
      </div>
      {open && (
        <div role="dialog" aria-label="Chart layers" className="glass-strong absolute bottom-0 left-full ml-3 w-64 animate-panel-in rounded-2xl p-2">
          <p className="px-2 pt-1 pb-2 text-[11px] font-semibold tracking-[0.16em] text-gv-cyan/80 uppercase">Layers</p>
          {layersPanel}
        </div>
      )}
    </div>
  );
}

/* ——— Right stack: zoom ——— */
export function ZoomControls({ onZoom, canIn, canOut }: { onZoom: (factor: number) => void; canIn: boolean; canOut: boolean }) {
  return (
    <div className="glass flex flex-col items-center gap-1 rounded-2xl p-1.5">
      <GlassIconButton label="Zoom in (+)" onClick={() => onZoom(1 / 1.5)} disabled={!canIn} className="disabled:opacity-35">
        <Plus className="h-6 w-6" strokeWidth={1.6} />
      </GlassIconButton>
      <span className="h-px w-8 bg-gv-cyan/15" aria-hidden />
      <GlassIconButton label="Zoom out (−)" onClick={() => onZoom(1.5)} disabled={!canOut} className="disabled:opacity-35">
        <Minus className="h-6 w-6" strokeWidth={1.6} />
      </GlassIconButton>
    </div>
  );
}

export function Toast({ message }: { message: string }) {
  return (
    <div role="status" className="glass pointer-events-none animate-panel-in rounded-full px-4 py-1.5 text-sm font-medium whitespace-nowrap text-gv-ice">
      {message}
    </div>
  );
}
