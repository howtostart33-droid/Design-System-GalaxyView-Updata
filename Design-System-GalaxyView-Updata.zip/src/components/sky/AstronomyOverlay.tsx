import { memo, useMemo } from "react";
import type { SkyObject } from "@/data/catalog";
import { KIND_STYLE, overlay } from "@/design/tokens";
import { objectPixelRadius, type SkyLayers } from "@/lib/renderSky";
import { paToScreen, type Projector } from "@/lib/sky";
import { cn } from "@/utils/cn";

interface Props {
  proj: Projector;
  fov: number;
  objects: SkyObject[];
  layers: SkyLayers;
  selectedId: string | null;
  onSelect: (id: string) => void;
  scope: { fov: number; label: string } | null;
  compass: boolean;
}

interface Placed {
  o: SkyObject;
  x: number;
  y: number;
  r: number;
  lx: number;
  ly: number;
  side: 1 | -1;
  leader: boolean;
}

const DSO = new Set(["galaxy", "nebula", "planetary", "cluster"]);
const SOLAR = new Set(["planet", "moon", "sun"]);

function labelThreshold(o: SkyObject, fov: number) {
  if (SOLAR.has(o.kind)) return true;
  if (o.kind === "constellation") return fov > 14;
  if (o.kind === "star") return (o.mag ?? 9) < 2.4 + Math.log2(Math.max(1, 60 / fov)) * 1.05;
  const rank = o.rank ?? 4;
  if (fov > 45) return rank <= 1;
  if (fov > 15) return rank <= 2;
  if (fov > 6) return rank <= 3;
  return true;
}

function layerAllows(o: SkyObject, l: SkyLayers) {
  if (DSO.has(o.kind)) return l.deepSky || o.id === "m31";
  if (SOLAR.has(o.kind)) return l.planets;
  if (o.kind === "star") return l.stars;
  if (o.kind === "constellation") return l.constellations;
  return true;
}

export const AstronomyOverlay = memo(function AstronomyOverlay({ proj, fov, objects, layers, selectedId, onSelect, scope, compass }: Props) {
  const { w, h } = proj;

  const { placed, markers } = useMemo(() => {
    const visible = objects.filter((o) => layerAllows(o, layers) && proj.inView(o.ra, o.dec, 20));
    const markers = visible.filter((o) => DSO.has(o.kind) && (fov < 25 || (o.rank ?? 4) <= 2));
    if (!layers.labels) return { placed: [] as Placed[], markers };
    const prio = (o: SkyObject) => (o.id === selectedId ? -10 : SOLAR.has(o.kind) ? -2 : o.kind === "constellation" ? 6 : (o.rank ?? 4) + (o.mag ?? 8) / 20);
    const cands = visible.filter((o) => o.id === selectedId || labelThreshold(o, fov)).sort((a, b) => prio(a) - prio(b));
    const mobile = w < 1024;
    const rects: [number, number, number, number][] = [
      [0, 0, Math.min(w, 380), mobile ? 150 : 110], // brand + coordinate HUD
      [w - 240, 0, w, 72], // field HUD
      [w / 2 - 130, 0, w / 2 + 130, mobile ? 0 : 60], // centred brand (desktop)
      [0, h - 150, 84, h], // locate / layers stack
      [w - 84, h - 150, w, h], // zoom stack
    ];
    const hit = (r: [number, number, number, number]) =>
      rects.some((q) => r[0] < q[2] && r[2] > q[0] && r[1] < q[3] && r[3] > q[1]) || r[0] < 4 || r[1] < 4 || r[2] > w - 4 || r[3] > h - 4;
    const out: Placed[] = [];
    for (const o of cands) {
      if (out.length >= 48) break;
      const [x, y] = proj.project(o.ra, o.dec);
      const tw = o.name.length * (o.kind === "constellation" ? 8.6 : 7.4) + 10;
      const th = 20;
      if (o.kind === "constellation") {
        const r: [number, number, number, number] = [x - tw / 2, y - th / 2, x + tw / 2, y + th / 2];
        if (hit(r)) continue;
        rects.push(r);
        out.push({ o, x, y, r: 0, lx: x - tw / 2, ly: y - th / 2, side: 1, leader: false });
        continue;
      }
      const rPx = Math.max(o.kind === "star" ? 4 : 6, Math.min(objectPixelRadius(o, proj.scale) * 0.5, 60));
      const d = rPx + (o.kind === "star" ? 10 : 22);
      const tries: [number, number, 1 | -1][] = [
        [d * 0.75, -d, 1],
        [-d * 0.75, -d, -1],
        [d * 0.75, d * 0.8, 1],
        [-d * 0.75, d * 0.8, -1],
      ];
      for (const [dx, dy, side] of tries) {
        const lx = side === 1 ? x + dx : x + dx - tw;
        const ly = y + dy - th / 2;
        const r: [number, number, number, number] = [lx - 2, ly - 2, lx + tw + 2, ly + th + 2];
        if (hit(r) && o.id !== selectedId) continue;
        rects.push(r, [x - 6, y - 6, x + 6, y + 6]);
        out.push({ o, x, y, r: rPx, lx, ly, side, leader: true });
        break;
      }
    }
    return { placed: out, markers };
  }, [objects, layers, proj, fov, selectedId, w, h]);

  const sel = selectedId ? objects.find((o) => o.id === selectedId) : undefined;
  const selPos = sel ? proj.project(sel.ra, sel.dec) : null;
  const selR = sel ? Math.max(16, Math.min(objectPixelRadius(sel, proj.scale) * 0.6, 140) + 8) : 0;

  const [cRa, cDec] = proj.unproject(w / 2, h / 2);
  const cN = proj.northAngle(cRa, cDec);

  return (
    <>
      <svg className="pointer-events-none absolute inset-0 h-full w-full" width={w} height={h} aria-hidden>
        <defs>
          <filter id="gv-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="1.6" result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <mask id="gv-scope">
            <rect width="100%" height="100%" fill="white" />
            {scope && <circle cx={w / 2} cy={h / 2} r={(scope.fov / 2) * proj.scale} fill="black" />}
          </mask>
        </defs>

        {/* Galaxy outlines */}
        {layers.outlines &&
          markers.map((o) => {
            if (o.kind !== "galaxy" || !o.size) return null;
            const [x, y] = proj.project(o.ra, o.dec);
            const rx = objectPixelRadius(o, proj.scale);
            if (rx < 14) return null;
            const ry = rx * (o.size.min / o.size.maj);
            const deg = (paToScreen(proj, o.ra, o.dec, o.size.pa ?? 0) * 180) / Math.PI;
            const isM31 = o.id === "m31";
            return (
              <g key={`ol-${o.id}`} transform={`rotate(${deg} ${x} ${y})`}>
                <ellipse cx={x} cy={y} rx={isM31 ? rx * 1.18 : rx * 1.1} ry={isM31 ? ry * 2.15 : ry * 1.15} fill="none" stroke={overlay.outline} strokeWidth={1.1} />
                {isM31 && <ellipse cx={x} cy={y} rx={rx * 0.93} ry={ry * 1.55} fill="none" stroke={overlay.outlineDash} strokeWidth={1} strokeDasharray="5 6" />}
              </g>
            );
          })}

        {/* DSO centre rings */}
        {markers.map((o) => {
          const [x, y] = proj.project(o.ra, o.dec);
          return <circle key={`mk-${o.id}`} cx={x} cy={y} r={3.6} fill="rgba(2,8,20,0.35)" stroke={overlay.marker} strokeWidth={1.2} />;
        })}

        {/* Leader lines */}
        {placed.map((p) => {
          if (!p.leader) return null;
          const tx = p.side === 1 ? p.lx : p.lx + (p.o.name.length * 7.4 + 10);
          const ty = p.ly + 10;
          const ang = Math.atan2(ty - p.y, tx - p.x);
          const r0 = p.o.kind === "star" ? 5 : DSO.has(p.o.kind) ? 4.5 : 7;
          return (
            <path
              key={`ld-${p.o.id}`}
              d={`M${p.x + Math.cos(ang) * r0} ${p.y + Math.sin(ang) * r0} L${tx - p.side * 6} ${ty} H${tx}`}
              fill="none"
              stroke={SOLAR.has(p.o.kind) ? "rgba(255,215,154,0.55)" : overlay.leader}
              strokeWidth={1}
            />
          );
        })}

        {/* Selection reticle */}
        {sel && selPos && selPos[2] > 0.05 && (
          <g className="animate-reticle" filter="url(#gv-glow)">
            <circle cx={selPos[0]} cy={selPos[1]} r={selR} fill="none" stroke="#38e1ff" strokeWidth={1.4} />
            {[0, 90, 180, 270].map((d) => (
              <line key={d} x1={selPos[0]} y1={selPos[1] - selR - 10} x2={selPos[0]} y2={selPos[1] - selR - 3} stroke="#38e1ff" strokeWidth={1.6} transform={`rotate(${d} ${selPos[0]} ${selPos[1]})`} />
            ))}
            <circle cx={selPos[0]} cy={selPos[1]} r={2} fill="#38e1ff" />
          </g>
        )}

        {/* Compass / orientation overlay */}
        {compass && <Compass w={w} h={h} north={cN} />}

        {/* Eyepiece */}
        {scope && (
          <g>
            <rect width="100%" height="100%" fill="rgba(1,3,8,0.72)" mask="url(#gv-scope)" />
            <circle cx={w / 2} cy={h / 2} r={(scope.fov / 2) * proj.scale} fill="none" stroke="#38e1ff" strokeWidth={1.5} filter="url(#gv-glow)" />
            <circle cx={w / 2} cy={h / 2} r={(scope.fov / 2) * proj.scale + 6} fill="none" stroke="rgba(56,225,255,0.3)" strokeWidth={1} strokeDasharray="2 5" />
          </g>
        )}
      </svg>

      {/* Interactive labels */}
      {placed.map((p) => {
        const style = KIND_STYLE[p.o.kind];
        const isSel = p.o.id === selectedId;
        const isCon = p.o.kind === "constellation";
        return (
          <button
            key={`lb-${p.o.id}`}
            type="button"
            data-object-id={p.o.id}
            onClick={() => onSelect(p.o.id)}
            aria-label={`${p.o.name}${p.o.alias ? `, ${p.o.alias}` : ""} — ${style.label}${p.o.mag !== undefined ? `, magnitude ${p.o.mag}` : ""}`}
            className={cn(
              "focus-ring absolute top-0 left-0 cursor-pointer rounded px-1 leading-5 whitespace-nowrap transition-colors duration-150 select-none",
              isCon
                ? "text-[11px] font-semibold tracking-[0.28em] text-[rgba(150,190,240,0.55)] uppercase hover:text-gv-ice"
                : cn(
                    "text-[13px] font-medium hover:text-white",
                    SOLAR.has(p.o.kind) ? "text-gv-warm" : p.o.kind === "star" ? "text-gv-ice/85" : "text-gv-cyan-soft",
                  ),
              isSel && "bg-gv-cyan/15 text-white text-glow",
            )}
            style={{ transform: `translate3d(${Math.round(p.lx)}px, ${Math.round(p.ly)}px, 0)`, textShadow: isSel ? undefined : "0 1px 3px rgba(0,0,0,0.9)" }}
          >
            {p.o.name}
          </button>
        );
      })}

      {scope && (
        <p
          className="pointer-events-none absolute left-1/2 -translate-x-1/2 text-[11px] font-semibold tracking-[0.2em] text-gv-cyan uppercase"
          style={{ top: Math.max(84, h / 2 - (scope.fov / 2) * proj.scale - 26) }}
        >
          {scope.label}
        </p>
      )}
    </>
  );
});

function Compass({ w, h, north }: { w: number; h: number; north: number }) {
  const cx = w / 2;
  const cy = h / 2;
  const rx = w / 2 - 40;
  const ry = h / 2 - 64;
  const pts = [
    { t: "N", a: north },
    { t: "E", a: north - Math.PI / 2 },
    { t: "S", a: north + Math.PI },
    { t: "W", a: north + Math.PI / 2 },
  ].map((d) => ({ ...d, x: cx + Math.cos(d.a) * rx, y: cy + Math.sin(d.a) * ry }));
  return (
    <g>
      <line x1={pts[0].x} y1={pts[0].y} x2={pts[2].x} y2={pts[2].y} stroke="rgba(140,190,240,0.45)" strokeWidth={1} strokeDasharray="4 6" />
      <line x1={pts[1].x} y1={pts[1].y} x2={pts[3].x} y2={pts[3].y} stroke="rgba(140,190,240,0.18)" strokeWidth={1} strokeDasharray="2 8" />
      {pts.map((p) => (
        <g key={p.t}>
          <circle cx={p.x} cy={p.y} r={16} fill="rgba(4,10,22,0.7)" stroke="rgba(56,225,255,0.65)" strokeWidth={1.2} />
          <text x={p.x} y={p.y + 5} textAnchor="middle" fontSize={14} fontWeight={600} fill={p.t === "N" ? "#38e1ff" : "#dbe9ff"} fontFamily="Inter, sans-serif">
            {p.t}
          </text>
        </g>
      ))}
    </g>
  );
}
