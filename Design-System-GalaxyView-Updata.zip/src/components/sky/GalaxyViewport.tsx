import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import galaxyUrl from "@/assets/galaxy-m31.jpg";
import type { SkyObject } from "@/data/catalog";
import type { Observer } from "@/lib/astro";
import { objectPixelRadius, renderSky, type SkyLayers } from "@/lib/renderSky";
import { clamp, makeProjector, MAX_FOV, MIN_FOV, type View } from "@/lib/sky";
import { AstronomyOverlay } from "./AstronomyOverlay";

interface Props {
  view: View;
  setView: (fn: (v: View) => View) => void;
  layers: SkyLayers;
  time: Date;
  observer: Observer;
  objects: SkyObject[];
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  scope: { fov: number; label: string } | null;
  compass: boolean;
  orbits: boolean;
  onUserMove?: () => void;
  onResize?: (w: number, h: number) => void;
}

/** Zoom keeping the sky point under (px,py) fixed. Shared by wheel, pinch and buttons. */
export function zoomView(v: View, factor: number, w: number, h: number, px = w / 2, py = h / 2): View {
  const fov = clamp(v.fov * factor, MIN_FOV, MAX_FOV);
  const k = fov / v.fov;
  const p = makeProjector(v, w, h);
  const [ra, dec] = p.unproject(px + (w / 2 - px) * k, py + (h / 2 - py) * k);
  return { ...v, ra, dec: clamp(dec, -89.99, 89.99), fov };
}

export function GalaxyViewport(props: Props) {
  const { view, setView, layers, time, observer, objects, selectedId, onSelect, scope, compass, orbits, onUserMove, onResize } = props;
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [size, setSize] = useState({ w: 0, h: 0 });
  const [img, setImg] = useState<HTMLImageElement | null>(null);

  // Lazy-load the galaxy texture once
  useEffect(() => {
    const im = new Image();
    im.decoding = "async";
    im.onload = () => setImg(im);
    im.src = galaxyUrl;
  }, []);

  useEffect(() => {
    const el = wrapRef.current!;
    const ro = new ResizeObserver(([e]) => {
      const s = { w: Math.round(e.contentRect.width), h: Math.round(e.contentRect.height) };
      setSize(s);
      onResize?.(s.w, s.h);
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, [onResize]);

  // Canvas render — batched to one frame per state change
  useEffect(() => {
    if (!size.w || !size.h) return;
    const c = canvasRef.current!;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const W = Math.round(size.w * dpr);
    const H = Math.round(size.h * dpr);
    if (c.width !== W || c.height !== H) {
      c.width = W;
      c.height = H;
    }
    const ctx = c.getContext("2d", { alpha: false })!;
    const id = requestAnimationFrame(() => {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      renderSky(ctx, { view, w: size.w, h: size.h, layers, time, observer, objects, galaxyImg: img, orbits });
    });
    return () => cancelAnimationFrame(id);
  }, [view, size, layers, time, observer, objects, img, orbits]);

  const proj = useMemo(() => makeProjector(view, size.w || 1, size.h || 1), [view, size]);

  // ——— Gestures ———
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const g = useRef({ moved: 0, pinch: 0, downId: null as string | null });

  const zoomAt = useCallback(
    (factor: number, px: number, py: number) => setView((v) => zoomView(v, factor, size.w, size.h, px, py)),
    [setView, size],
  );

  useEffect(() => {
    const el = wrapRef.current!;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const r = el.getBoundingClientRect();
      onUserMove?.();
      zoomAt(Math.exp(e.deltaY * 0.0014), e.clientX - r.left, e.clientY - r.top);
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, [zoomAt, onUserMove]);

  const onPointerDown = (e: React.PointerEvent) => {
    g.current.downId = (e.target as HTMLElement).closest?.("[data-object-id]")?.getAttribute("data-object-id") ?? null;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    g.current.moved = 0;
    if (pointers.current.size === 2) {
      const [a, b] = [...pointers.current.values()];
      g.current.pinch = Math.hypot(a.x - b.x, a.y - b.y);
    }
  };

  const onPointerMove = (e: React.PointerEvent) => {
    const prev = pointers.current.get(e.pointerId);
    if (!prev) return;
    const cur = { x: e.clientX, y: e.clientY };
    pointers.current.set(e.pointerId, cur);
    if (pointers.current.size === 2) {
      const [a, b] = [...pointers.current.values()];
      const d = Math.hypot(a.x - b.x, a.y - b.y);
      if (g.current.pinch > 0 && d > 0) {
        const r = wrapRef.current!.getBoundingClientRect();
        zoomAt(g.current.pinch / d, (a.x + b.x) / 2 - r.left, (a.y + b.y) / 2 - r.top);
      }
      g.current.pinch = d;
      g.current.moved += 10;
      onUserMove?.();
      return;
    }
    const dx = cur.x - prev.x;
    const dy = cur.y - prev.y;
    g.current.moved += Math.abs(dx) + Math.abs(dy);
    if (g.current.moved < 4) return;
    onUserMove?.();
    setView((v) => {
      const p = makeProjector(v, size.w, size.h);
      const [ra, dec] = p.unproject(size.w / 2 - dx, size.h / 2 - dy);
      return { ...v, ra, dec: clamp(dec, -89.99, 89.99) };
    });
  };

  const onPointerUp = (e: React.PointerEvent) => {
    pointers.current.delete(e.pointerId);
    if (pointers.current.size < 2) g.current.pinch = 0;
    if (g.current.moved > 5 || pointers.current.size > 0) return;
    if (g.current.downId) return onSelect(g.current.downId);
    const r = wrapRef.current!.getBoundingClientRect();
    const px = e.clientX - r.left;
    const py = e.clientY - r.top;
    let best: SkyObject | null = null;
    let bestD = 20;
    for (const o of objects) {
      if (o.kind === "constellation") continue;
      const [x, y, c] = proj.project(o.ra, o.dec);
      if (c < 0.1) continue;
      const d = Math.hypot(x - px, y - py);
      if (d < bestD) (bestD = d), (best = o);
    }
    if (!best) {
      // inside an extended galaxy's outline?
      for (const o of objects) {
        if (o.kind !== "galaxy" || !o.size) continue;
        const [x, y, c] = proj.project(o.ra, o.dec);
        const rx = objectPixelRadius(o, proj.scale);
        if (c > 0.1 && rx > 20 && Math.hypot(x - px, y - py) < rx * (o.size.min / o.size.maj) * 1.4) best = o;
      }
    }
    onSelect(best ? best.id : null);
  };

  return (
    <div
      ref={wrapRef}
      className="absolute inset-0 cursor-grab touch-none overflow-hidden active:cursor-grabbing"
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
      role="application"
      aria-roledescription="sky chart"
      aria-label="Interactive sky chart. Drag to pan, scroll or pinch to zoom, tap or press Tab to reach object labels."
    >
      <canvas ref={canvasRef} className="absolute inset-0 block h-full w-full" />
      {size.w > 0 && (
        <AstronomyOverlay
          proj={proj}
          fov={view.fov}
          objects={objects}
          layers={layers}
          selectedId={selectedId}
          onSelect={onSelect}
          scope={scope}
          compass={compass}
        />
      )}
    </div>
  );
}
