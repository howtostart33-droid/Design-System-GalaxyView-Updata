import { memo } from "react";
import {
  CalendarDays,
  CircleHelp,
  Clock,
  Compass,
  Info,
  Moon,
  Orbit,
  Search,
  Settings,
  Share2,
  Sparkles,
  Target,
  Telescope,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/utils/cn";

export type ToolId = "search" | "info" | "center" | "settings" | "time" | "scope" | "orbit" | "compass" | "night" | "skyweek" | "tonight" | "share" | "help";

export interface ToolDef {
  id: ToolId;
  label: string;
  icon: LucideIcon;
  kind: "panel" | "toggle" | "action";
  key: string;
  hint: string;
}

export const TOOLS: ToolDef[] = [
  { id: "search", label: "Search", icon: Search, kind: "panel", key: "/", hint: "Find stars, planets, galaxies…" },
  { id: "info", label: "Info", icon: Info, kind: "panel", key: "I", hint: "Details of the selected object" },
  { id: "center", label: "Center", icon: Target, kind: "action", key: "C", hint: "Center on target / reset view" },
  { id: "settings", label: "Settings", icon: Settings, kind: "panel", key: ",", hint: "Layers, display & location" },
  { id: "time", label: "Time", icon: Clock, kind: "panel", key: "T", hint: "Change the chart time" },
  { id: "scope", label: "Scope", icon: Telescope, kind: "panel", key: "S", hint: "Eyepiece field of view" },
  { id: "orbit", label: "Orbit", icon: Orbit, kind: "toggle", key: "O", hint: "Ecliptic & planet orbit tracks" },
  { id: "compass", label: "Compass", icon: Compass, kind: "toggle", key: "K", hint: "Orientation overlay" },
  { id: "night", label: "Night", icon: Moon, kind: "toggle", key: "N", hint: "Red night-vision mode" },
  { id: "skyweek", label: "SKY", icon: Sparkles, kind: "panel", key: "W", hint: "SkyWeek — the next 7 nights" },
  { id: "tonight", label: "Tonight", icon: CalendarDays, kind: "panel", key: "G", hint: "Best targets above your horizon" },
  { id: "share", label: "Share", icon: Share2, kind: "panel", key: "X", hint: "Share this exact view" },
  { id: "help", label: "Help", icon: CircleHelp, kind: "panel", key: "?", hint: "Controls & shortcuts" },
];

interface Props {
  active: Partial<Record<ToolId, boolean>>;
  onTool: (id: ToolId) => void;
}

export const BottomNavigation = memo(function BottomNavigation({ active, onTool }: Props) {
  return (
    <nav aria-label="Galaxy View tools" className="pointer-events-auto relative z-50 px-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] sm:px-3">
      <ul className="glass-strong no-scrollbar mx-auto flex max-w-[1400px] snap-x items-stretch overflow-x-auto rounded-2xl px-1.5 py-1.5 lg:justify-between">
        {TOOLS.map((t, i) => {
          const on = !!active[t.id];
          const Icon = t.icon;
          return (
            <li key={t.id} className="relative flex shrink-0 snap-start items-stretch lg:flex-1">
              {i > 0 && <span aria-hidden className="my-3 w-px bg-gv-cyan/10" />}
              <button
                type="button"
                onClick={() => onTool(t.id)}
                aria-pressed={t.kind === "action" ? undefined : on}
                aria-keyshortcuts={t.key}
                aria-label={`${t.label === "SKY" ? "SkyWeek" : t.label}: ${t.hint}`}
                className={cn(
                  "focus-ring group relative mx-0.5 flex min-w-[64px] flex-1 cursor-pointer flex-col items-center justify-center gap-1 rounded-xl border border-transparent px-2 py-2 transition-all duration-200 sm:min-w-[74px]",
                  on ? "glow-active text-gv-cyan" : "text-gv-ice/90 hover:bg-white/[0.04] hover:text-white",
                  "active:scale-[0.96]",
                )}
              >
                <Icon className={cn("h-6 w-6 transition-transform duration-200 group-hover:-translate-y-0.5 sm:h-7 sm:w-7", on && "drop-shadow-[0_0_8px_rgba(56,225,255,0.7)]")} strokeWidth={1.5} aria-hidden />
                <span className={cn("text-[11px] font-medium sm:text-[13px]", t.id === "skyweek" && "font-bold tracking-wider")}>{t.label}</span>
                {on && <span aria-hidden className="absolute inset-x-5 -bottom-px h-0.5 rounded-full bg-gv-cyan shadow-[0_0_10px_#38e1ff]" />}
                {/* Tooltip (pointer + keyboard focus) */}
                <span
                  role="tooltip"
                  className="glass-strong pointer-events-none absolute bottom-full left-1/2 mb-3 hidden -translate-x-1/2 rounded-lg px-3 py-1.5 text-xs whitespace-nowrap text-gv-ice opacity-0 transition-opacity duration-150 group-hover:opacity-100 group-focus-visible:opacity-100 lg:block"
                >
                  {t.hint}
                  <kbd className="ml-2 rounded border border-gv-cyan/30 px-1.5 font-sans text-[10px] text-gv-cyan">{t.key}</kbd>
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
});
